--z infinite buffer chest, technology 
data:extend(
{
  {
    type = "technology",
    name = "Infinite_Buffer_Chest",
    icon = "__Infinite_Buffer_Chest__/graphics/technology/2x2-chest.png",
    icon_size = 128,
	prerequisites = {"steel-processing"},
    effects = {
					{
						type = "unlock-recipe",
						recipe = "Infinite_Buffer_Chest"
				    },
			  },
   unit =
		{
        count = 100,
        ingredients =
          {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
          },
        time = 5
		}
   
 },
}
)

data:extend(
{
  {
    type = "recipe",
    name = "Infinite_Buffer_Chest",
	enabled = false,
    ingredients =
	{
		{"iron-plate", 1000},
		{"steel-plate", 200},
		{"copper-plate", 1000},
		{"stone-brick", 500},
		{"iron-gear-wheel", 100},
		{"electronic-circuit", 1}
	},
	energy_required = 300,
    result = "Infinite_Buffer_Chest"
  },
}
)

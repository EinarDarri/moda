data:extend(
{
  {
    type = "item",
    name = "Infinite_Buffer_Chest",
    icon =  "__Infinite_Buffer_Chest__/graphics/icons/2x2-chest.png", 
    icon_size = 32,
    subgroup = "storage",
    order = "aab",
    place_result = "Infinite_Buffer_Chest",
    stack_size = 3
  },  
 }
)

require("prototypes.item")
require("prototypes.entities")
require("prototypes.recipe")
require("prototypes.technology")
data:extend(
{
	{
		type = "recipe",
		name = "god-module",
		enabled = false,
    	category = "crafting-with-fluid",
		ingredients =
		{
			{"god-module-speed", 1},
			{"god-module-effectivity", 1},
			{"god-module-productivity", 1},
	      	{type="fluid", name="water", amount=9000}
		},
		energy_required = 120,
		result = "god-module"
	},


	{
		type = "recipe",
		name = "god-module-speed",
		enabled = false,
    	category = "crafting-with-fluid",
		ingredients =
		{
			{"speed-module-3", 3},
	      	{type="fluid", name="water", amount=3000}
		},
		energy_required = 120,
		result = "god-module-speed"
	},

	{
		type = "recipe",
		name = "god-module-effectivity",
		enabled = false,
    	category = "crafting-with-fluid",
		ingredients =
		{
			{"effectivity-module-3", 3},
	      	{type="fluid", name="water", amount=3000}
		},
		energy_required = 120,
		result = "god-module-effectivity"
	},

	{
		type = "recipe",
		name = "god-module-productivity",
		enabled = false,
    	category = "crafting-with-fluid",
		ingredients =
		{
			{"productivity-module-3", 3},
	      	{type="fluid", name="water", amount=3000}
		},
		energy_required = 120,
		result = "god-module-productivity"
	}
})
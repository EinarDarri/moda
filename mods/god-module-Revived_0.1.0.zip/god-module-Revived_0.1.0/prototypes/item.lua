function get_all_effect()
	return {
		speed = { bonus = settings.startup["god-module-speed-bonus"].value / 100 },
		consumption = { bonus = settings.startup["god-module-efficiency-bonus"].value / 100 * -1 },
		productivity = { bonus = settings.startup["god-module-productivity-bonus"].value / 100 }
	}
end

function get_speed_effect()
	return {
		speed = { bonus = settings.startup["god-speed-module-speed-bonus"].value / 100 }
	}
end

function get_effectivity_effect()
	return {
		consumption = { bonus = settings.startup["god-efficiency-module-efficiency-bonus"].value / 100 * -1 }
	}
end

function get_productivity_effect()
	return {
		productivity = { bonus = settings.startup["god-productivity-module-productivity-bonus"].value / 100 }
	}
end



data:extend(
{
	{
	    type = "module",
	    name = "god-module",
		icon = "__god-module-Revived__/graphics/icons/god-module.png",
		icon_size = 32,
	    subgroup = "module",
	    category = "speed",
	    tier = 3,
	    order = "d[god-module]",
	    stack_size = 50,
	    default_request_amount = 10,
	    effect = get_all_effect()
	},


	{
	    type = "module",
	    name = "god-module-speed",
		icon = "__god-module-Revived__/graphics/icons/god-module-speed.png",
		icon_size = 32,
	    subgroup = "module",
	    category = "speed",
	    tier = 3,
	    order = "a[speed]-d[speed-module-4]",
	    stack_size = 50,
	    default_request_amount = 10,
	    effect = get_speed_effect()
	},


	{
	    type = "module",
	    name = "god-module-effectivity",
		icon = "__god-module-Revived__/graphics/icons/god-module-effectivity.png",
		icon_size = 32,
	    subgroup = "module",
	    category = "effectivity",
	    tier = 3,
	    order = "c[effectivity]-d[effectivity-module-4]",
	    stack_size = 50,
	    default_request_amount = 10,
	    effect = get_effectivity_effect("effectivity")
	},


	{
	    type = "module",
	    name = "god-module-productivity",
		icon = "__god-module-Revived__/graphics/icons/god-module-productivity.png",
		icon_size = 32,
	    subgroup = "module",
	    category = "productivity",
	    tier = 3,
	    order = "c[productivity]-d[productivity-module-4]",
	    stack_size = 50,
	    default_request_amount = 10,
	    effect = get_productivity_effect("productivity"),
    	--limitation = productivitymodulelimitation(),
    	--limitation_message_key = "production-module-usable-only-on-intermediates"
	}
})
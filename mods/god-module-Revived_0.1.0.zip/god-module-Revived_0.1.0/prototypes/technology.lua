data:extend(
{
	{
	    type = "technology",
	    name = "god-module",
	    icon = "__god-module-Revived__/graphics/technology/god-module.png",
		icon_size = 128,
		effects =
		{
			{
				type = "unlock-recipe",
				recipe = "god-module"
			},
			{
				type = "unlock-recipe",
				recipe = "god-module-speed"
			},
			{
				type = "unlock-recipe",
				recipe = "god-module-effectivity"
			},
			{
				type = "unlock-recipe",
				recipe = "god-module-productivity"
			}
		},
		icon_size = 128,
	    prerequisites = {"speed-module-3", "effectivity-module-3", "productivity-module-3"},
	    unit =
	    {
      		count = 300,
      		ingredients =
      		{
		        {"automation-science-pack", 1},
		        {"logistic-science-pack", 1},
		        {"military-science-pack", 1},
		        {"chemical-science-pack", 1},
		        {"production-science-pack", 1},
        		{"utility-science-pack", 1}
      		},
      		time = 60
	    },
	    upgrade = true,
	    order = "i-c-d"
	},	
})
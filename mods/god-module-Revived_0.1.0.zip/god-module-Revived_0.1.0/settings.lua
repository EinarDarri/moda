data:extend({
    {
        type = "int-setting",
        name = "god-speed-module-speed-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a1"
    },
    {
        type = "int-setting",
        name = "god-efficiency-module-efficiency-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a2"
    },
    {
        type = "int-setting",
        name = "god-productivity-module-productivity-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "a3"
    },

    
    {
        type = "int-setting",
        name = "god-module-speed-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b1"
    },
    {
        type = "int-setting",
        name = "god-module-efficiency-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b2"
    },
    {
        type = "int-setting",
        name = "god-module-productivity-bonus",
        setting_type = "startup",
        minimum_value = 1,
        default_value = 50,
        maximum_value = 500,
        order = "b3"
    }
})
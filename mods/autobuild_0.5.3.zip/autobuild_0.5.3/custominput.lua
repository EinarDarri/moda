data:extend{
  {
    type = "custom-input",
    name = "autobuild-custominput-toggle-construction",
    key_sequence = "SHIFT + B",
  },
  {
    type = "custom-input",
    name = "autobuild-custominput-toggle-tiles",
    key_sequence = "CONTROL + SHIFT + B",
  },
}

data:extend(
{
   {
      type = "bool-setting",
      name = "god-module-extreme",
      setting_type = "startup",
      default_value = false,
   }
})
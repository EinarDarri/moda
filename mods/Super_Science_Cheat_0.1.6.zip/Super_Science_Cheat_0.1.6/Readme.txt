Many thanks to DellAquila (MayorAquila).

I was inspired by his Initial Bus Cheat to make this.

To do:

Deconflict with his Initial Bus Cheat mod

Create similar mod that produces all seven science


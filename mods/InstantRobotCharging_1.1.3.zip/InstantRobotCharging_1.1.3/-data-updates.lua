-- data.raw.roboport.roboport.charging_energy = "1000kW" 
data.raw.roboport.roboport.charging_energy = "1210MW" 


-- only two charging points:
--data.raw.roboport.roboport.charging_offsets = {{1.5,1.5},{-1.5,1.5}}
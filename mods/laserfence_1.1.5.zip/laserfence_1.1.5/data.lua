modName = "__laserfence__"

require ("prototypes.laserfence")
require ("prototypes.item")
require ("prototypes.recipe")
require ("prototypes.technology")

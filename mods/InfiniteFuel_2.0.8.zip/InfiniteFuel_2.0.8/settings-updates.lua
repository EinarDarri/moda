if mods["Krastorio2"] then
    data.raw["bool-setting"]["IF-kr-Infinite-Fuel"].hidden = false
end
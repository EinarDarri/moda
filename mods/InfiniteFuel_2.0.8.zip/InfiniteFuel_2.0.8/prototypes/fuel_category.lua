data:extend({
    {
        type = "fuel-category",
        name = "IF",
        localised_name = "omni fuel",
    },
    {
        type = "fuel-category",
        name = "nothing",
        localised_name = "if this is showed an error as occurred",
    }
})

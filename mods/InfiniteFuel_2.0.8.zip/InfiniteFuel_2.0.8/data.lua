--vamilla
require("prototypes.item")
require("prototypes.recipe")
require("prototypes.technology")
require("prototypes.fuel_category")
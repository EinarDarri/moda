data:extend(
{
   {
      type = "ammo-category",
      name = "laser-gun-ammo"
   }
})

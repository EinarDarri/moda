data:extend(
{
   {
      type = "recipe",
      name = "laser-gun",
      enabled = false,
      energy_required = 10,
      ingredients =
      {
         {"steel-plate", 10},
         {"processing-unit", 10},
         {"battery", 5}
      },
      result = "laser-gun"
   },
   {
      type = "recipe",
      name = "laser-minigun",
      enabled = false,
      energy_required = 10,
      ingredients =
      {
         {"steel-plate", 20},
         {"advanced-circuit", 20},
         {"battery", 10},
         {"processing-unit", 10},
         {"iron-gear-wheel", 40},
      },
      result = "laser-minigun"
   },
   {
      type = "recipe",
      name = "laser-gun-magazine",
      enabled = false,
      energy_required = 6,
      ingredients =
      {
         {"steel-plate", 4},
         {"advanced-circuit", 1},
         {"battery", 2}
      },
      result = "laser-gun-magazine"
   }
})

data:extend(
{
   {
      type = "gun",
      name = "laser-gun",
      icon = "__LaserWeapons__/graphics/icon/laser-gun.png",
      icon_size = 1024,
      flags = {"not-stackable"},
      subgroup = "gun",
      order = "f[laser]",
      attack_parameters =
      {
         type = "projectile",
         ammo_category = "laser-gun-ammo",
         explosion = "explosion-gunshot",
         cooldown = 6,
         movement_slow_down_factor = 0.456,
         damage_modifier = 1.5,
         projectile_creation_distance = 1.125,
         range = settings.startup["setting_max-range"].value,
         sound = make_laser_sounds(),
      },
      stack_size = 1
   },
   {
      type = "gun",
      name = "laser-minigun",
      icon = "__LaserWeapons__/graphics/icon/laser-minigun.png",
      icon_size = 128,
      flags = {},
      subgroup = "gun",
      order = "f[laser]",
      attack_parameters =
      {
         type = "projectile",
         ammo_category = "laser-gun-ammo",
         cooldown = 1.25,
         movement_slow_down_factor = 1,
         projectile_creation_distance = 1.125,
         range = settings.startup["setting_max-range"].value - 10,
         sound = make_laser_sounds(),
      },
      stack_size = 1
   },
   {
      type = "ammo",
      name = "laser-gun-magazine",
      icon = "__LaserWeapons__/graphics/icon/laser-magazine.png",
      icon_size = 32,
      flags = {},
      ammo_type =
      {
         category = "laser-gun-ammo",
         action =
         {
            type = "direct",
            repeat_count = 10,
               action_delivery =
               {
                  type = "projectile",
                  projectile = "Laser-Gun-Bullet",
                  starting_speed = 2,
                  direction_deviation = 0,
                  range_deviation = 0,
                  max_range = settings.startup["setting_max-range"].value
               }
            }
         },
         magazine_size = 25,
         subgroup = "ammo",
         order = "f[laser]",
         stack_size = 100
      }
   })

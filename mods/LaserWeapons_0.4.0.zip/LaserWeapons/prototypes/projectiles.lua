data:extend({
   {
      type = "projectile",
      name = "Laser-Gun-Bullet",
      flags = {"not-on-map"},
      collision_box = {{-0.05, -0.25}, {0.05, 0.25}},
      acceleration = 0,
      direction_only = true,
      action =
      {
         type = "direct",
         action_delivery =
         {
            type = "instant",
            target_effects =
            {
               {
                  type = "damage",
                  damage = {amount = settings.startup["setting_base-physical-damage"].value, type = "physical"}
               },
               {
                  type = "damage",
                  damage = {amount = settings.startup["setting_base-laser-damage"].value , type = "laser"}
               }
            }
         }
      },
      animation =
      {
         filename = "__LaserWeapons__/graphics/icon/laserbullet.png",
         frame_count = 1,
         width = 3,
         height = 50,
         priority = "high"
      },
   }
})

data:extend(
{
   {
      type = "technology",
      name = "Laser-Gun",
      icon = "__LaserWeapons__/graphics/icon/laser-gun.png",
      icon_size = 1024,
      prerequisites=
      {
         "laser-turret",
         "military-3"
      },
      effects =
      {
         {
            type = "unlock-recipe",
            recipe = "laser-gun"
         },
         {
            type = "unlock-recipe",
            recipe = "laser-gun-magazine"
         }
      },
      unit =
      {
         count = 1000,
         ingredients =
         {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1},
            {"military-science-pack", 1},
            {"chemical-science-pack", 1}

         },
         time = 15
      },
      order = "c-a"
   },
   {
      type = "technology",
      name = "Laser-Minigun",
      icon = "__LaserWeapons__/graphics/icon/laser-minigun.png",
      icon_size = 128,
      prerequisites=
      {
         "Laser-Gun",
         "rocket-silo"
      },
      effects =
      {
         {
            type = "unlock-recipe",
            recipe = "laser-minigun"
         },
      },
      unit =
      {
         count = 5000,
         ingredients =
         {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1},
            {"military-science-pack", 1},
            {"chemical-science-pack", 1},
            {"production-science-pack", 1},
            {"utility-science-pack", 1},
            {"space-science-pack", 1}
         },
         time = 15
      },
      order = "c-a"
   },
})

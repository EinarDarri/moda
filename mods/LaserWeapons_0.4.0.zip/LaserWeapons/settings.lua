data:extend{
  {
    type = "int-setting",
    name = "setting_base-physical-damage",
    setting_type = "startup",
    min_value = 1,
    default_value = 20,
    max_value = 500,
    order = "a"
  },
  {
    type = "int-setting",
    name = "setting_base-laser-damage",
    setting_type = "startup",
    min_value = 1,
    default_value = 80,
    max_value = 500,
    order = "b"
  },
  {
    type = "int-setting",
    name = "setting_max-range",
    setting_type = "startup",
    min_value = 25,
    default_value = 50,
    max_value = 100,
    order = "c"
  }
}

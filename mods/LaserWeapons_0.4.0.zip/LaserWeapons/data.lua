require("prototypes.projectiles");
require("prototypes.item");
require("prototypes.technology");
require("prototypes.recipe");
require("prototypes.ammo-category");
--- Functions from high pressure pipes by kendfrey (the license is MIT so pls don't sue me k) ---
local function tintPictures(pictures, tint)
	for _, picture in pairs(pictures) do
		picture.tint = tint
		if picture.hr_version then
			picture.hr_version.tint = tint
		end
	end
end

local function mapMany(array, f)
	local result = {}
	for _, vs in pairs(array) do
		for _, v in pairs(f(vs)) do
			table.insert(result, v)
		end
	end
	return result;
end

local hc_hx = util.table.deepcopy(data.raw.boiler["heat-exchanger"])
hc_hx.name = "rfp-hc-exchanger"
hc_hx.energy_consumption = "100MW"
hc_hx.minable.result = "rfp-hc-exchanger"
tintPictures(hc_hx.structure.north.layers, {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(hc_hx.structure.west.layers, {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(hc_hx.structure.south.layers, {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(hc_hx.structure.east.layers, {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(mapMany(hc_hx.fluid_box.pipe_covers, function (p) return p.layers; end), {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(mapMany(hc_hx.output_fluid_box.pipe_covers, function (p) return p.layers; end), {r = 1, g = 0.5, b = 0, a = 1})

local hc_t = util.table.deepcopy(data.raw.generator["steam-turbine"])
hc_t.name = "rfp-hc-turbine"
hc_t.fluid_usage_per_tick = 10
hc_t.minable.result = "rfp-hc-turbine"
tintPictures(hc_t.horizontal_animation.layers, {r = 1, g = 0.5, b = 0, a = 1})
tintPictures(hc_t.vertical_animation.layers, {r = 1, g = 0.5, b = 0, a = 1})

data:extend({hc_hx, hc_t})
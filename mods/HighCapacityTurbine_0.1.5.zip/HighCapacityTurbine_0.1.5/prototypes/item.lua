local hc_hx = util.table.deepcopy(data.raw.item["heat-exchanger"])
hc_hx.name = "rfp-hc-exchanger"
hc_hx.place_result = "rfp-hc-exchanger"
hc_hx.icon = nil
hc_hx.icons = {{icon = data.raw.item["heat-exchanger"].icon, tint = {r = 1, g = 0.5, b = 0, a = 1}, icon_size = 64}}
hc_hx.order = hc_hx.order .. "a"

local hc_t = util.table.deepcopy(data.raw.item["steam-turbine"])
hc_t.name = "rfp-hc-turbine"
hc_t.place_result = "rfp-hc-turbine"
hc_t.icon = nil
hc_t.icons = {{icon = data.raw.item["steam-turbine"].icon, tint = {r = 1, g = 0.5, b = 0, a = 1}, icon_size = 64}}
hc_t.order = hc_t.order .. "a"

data:extend({hc_hx, hc_t})
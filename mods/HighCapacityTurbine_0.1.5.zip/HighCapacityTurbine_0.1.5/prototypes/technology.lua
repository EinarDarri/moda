data:extend({
--HC turbine and exchanger
{
    type = "technology",
    name = "rfp-hc-turbine-and-exchanger",
    icons = {{
        icon = "__base__/graphics/technology/fluid-handling.png",
        icon_size = 128,
        tint = {r = 1, g = 0.5, b = 0}
    }},
    effects = {
        {
            type = "unlock-recipe",
            recipe = "rfp-hc-exchanger"
        },
        {
            type = "unlock-recipe",
            recipe = "rfp-hc-turbine"
        }
    },
    prerequisites = {"nuclear-power", "utility-science-pack"},
    unit = {
        ingredients = {
          {"automation-science-pack", 1},
          {"logistic-science-pack", 1},
          {"chemical-science-pack", 1},
          {"production-science-pack", 1},
          {"utility-science-pack", 1},
        },
        time = 35,
        count = 1000
    },
}
})

data:extend({
    {
        type = "recipe",
        name = "rfp-hc-exchanger",
        energy_required = 3,
        ingredients = {{"steel-plate", 100}, {"copper-plate", 1000}, {"pipe", 100}},
        result = "rfp-hc-exchanger",
        enabled = false
    },
    {
        type = "recipe",
        name = "rfp-hc-turbine",
        energy_required = 3,
        ingredients = {{"iron-gear-wheel", 500}, {"copper-plate", 500}, {"pipe", 200}},
        result = "rfp-hc-turbine",
        enabled = false
    }
})
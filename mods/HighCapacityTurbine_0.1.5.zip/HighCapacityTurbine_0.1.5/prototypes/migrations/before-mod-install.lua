game.player.force.resetrecipes()
game.player.force.resettechnologies()
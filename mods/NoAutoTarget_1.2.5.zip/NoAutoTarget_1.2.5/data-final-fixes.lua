require("prototypes/entity/projectiles")

local am_type = {
	category = "bullet",
    target_type = "direction",
    action = {
        {
            type = "direct",
            action_delivery = {
                {
                    type = "projectile",
                    projectile = 'shotgun-pellet',
                    starting_speed = 1,
                    max_range = 30,
                    source_effects = {
                        {
                            type = "create-explosion",
                            entity_name = "explosion-gunshot"
                        }
                    }
                }
            }
        }
    }
}
local am_type1 = {
	category = "bullet",
    target_type = "direction",
    action = {
        {
            type = "direct",
            action_delivery = {
                {
                    type = "projectile",
                    projectile = 'shotgun-pellet1',
                    starting_speed = 1,
                    max_range = 30,
                    source_effects = {
                        {
                            type = "create-explosion",
                            entity_name = "explosion-gunshot"
                        }
                    }
                }
            }
        }
    }
}
local am_type2 = {
	category = "bullet",
    target_type = "direction",
    action = {
        {
            type = "direct",
            action_delivery = {
                {
                    type = "projectile",
                    projectile = 'shotgun-pellet2',
                    starting_speed = 1,
                    max_range = 30,
                    source_effects = {
                        {
                            type = "create-explosion",
                            entity_name = "explosion-gunshot"
                        }
                    }
                }
            }
        }
    }
}
local am_type3 = {
	category = "shotgun-shell",
	target_type = "direction",
	clamp_position = true,
	action = {
        {
			type = "direct",
			action_delivery = {
				type = "instant",
				source_effects = {
					{
					type = "create-explosion",
					entity_name = "explosion-gunshot"
					}
				}
			}
        },
        {
			type = "direct",
			repeat_count = 12,
			action_delivery = {
				type = "projectile",
				projectile = "shotgun-pellet",
				starting_speed = 1,
				starting_speed_deviation = 0.1,
				direction_deviation = 0.3,
				range_deviation = 0.3,
				max_range = 15
			}
        }
    }
}
local am_type4 = {
	category = "shotgun-shell",
	target_type = "direction",
	clamp_position = true,
	action = {
        {
			type = "direct",
			action_delivery = {
				type = "instant",
				source_effects = {
					{
					type = "create-explosion",
					entity_name = "explosion-gunshot"
					}
				}
			}
        },
        {
			type = "direct",
			repeat_count = 12,
			action_delivery = {
				type = "projectile",
				projectile = "shotgun-pellet1",
				starting_speed = 1,
				starting_speed_deviation = 0.1,
				direction_deviation = 0.3,
				range_deviation = 0.3,
				max_range = 15
			}
        }
    }
}
local am_type5 = {
	category = "rocket",
	target_type = "direction",
      action =
      {
        type = "direct",
        action_delivery =
        {
          type = "projectile",
          projectile = "rocketS",
          starting_speed = 0.1,
          source_effects =
          {
            type = "create-entity",
            entity_name = "explosion-hit"
          }
        }
      }
}
local am_type6 = {
	category = "rocket",
	target_type = "direction",
	action = {
		type = "direct",
		action_delivery = {
			type = "projectile",
			projectile = "explosive-rocket",
			starting_speed = 0.1,
			source_effects = {
				type = "create-entity",
				entity_name = "explosion-hit"
			}
		}
	}
}

data.raw.ammo['firearm-magazine'].ammo_type = am_type
data.raw.ammo['piercing-rounds-magazine'].ammo_type = am_type1
data.raw.ammo['uranium-rounds-magazine'].ammo_type = am_type2
data.raw.ammo['shotgun-shell'].ammo_type = am_type3
data.raw.ammo['piercing-shotgun-shell'].ammo_type = am_type4
data.raw.ammo['rocket'].ammo_type = am_type5
data.raw.ammo['explosive-rocket'].ammo_type = am_type6


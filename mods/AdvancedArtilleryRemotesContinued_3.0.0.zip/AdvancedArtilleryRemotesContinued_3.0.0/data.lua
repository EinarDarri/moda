-- Copyright (c) 2020 Dockmeister
-- Copyright (c) 2022 Branko Majic
-- Provided under MIT license. See LICENSE for details.


require "prototypes/artillery-cluster-remote"
require "prototypes/artillery-discovery-remote"

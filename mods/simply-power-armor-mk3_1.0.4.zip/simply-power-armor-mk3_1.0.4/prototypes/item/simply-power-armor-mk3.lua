for _, animation in ipairs(data.raw["character"]["character"]["animations"]) do
  if animation.armors then
    for _, armor in ipairs(animation.armors) do
      if armor == "power-armor-mk2" then
        animation.armors[#animation.armors + 1] = "simply-power-armor-mk3"
        break
      end
    end
  end
end

data:extend(
{
  {
    type = "armor",
    name = "simply-power-armor-mk3",
    icon = "__simply-power-armor-mk3__/graphics/icons/simply-power-armor-mk3.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "physical",
        decrease = 12,
        percent = 40
      },
      {
        type = "acid",
        decrease = 0,
        percent = 80
      },
      {
        type = "explosion",
        decrease = 80,
        percent = 60
      },
      {
        type = "fire",
        decrease = 0,
        percent = 80
      }
    },
    subgroup = "armor",
    order = "e[power-armor-mk3]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "simply-mk3-equipment-grid",
    inventory_size_bonus = 40
  }
}
)

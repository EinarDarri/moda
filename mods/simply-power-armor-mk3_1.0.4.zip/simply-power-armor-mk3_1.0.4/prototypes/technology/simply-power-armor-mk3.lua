data:extend({
	{
		type = "technology",
		name = "simply-power-armor-mk3",
		icon_size = 128,
		icon = "__simply-power-armor-mk3__/graphics/technology/simply-power-armor-mk3-tech.png",
		effects =  {
			{
				type = "unlock-recipe",
				recipe = "simply-power-armor-mk3"
			},
		},
		prerequisites = {"power-armor-mk2", "speed-module-3", "effectivity-module-3"},
		unit = {
			count = 800,
			ingredients = {
				{"automation-science-pack", 1},
				{"logistic-science-pack", 1},
				{"chemical-science-pack", 1},
				{"military-science-pack", 1},
				{"production-science-pack", 1},
				{"utility-science-pack", 1}
			},
			time = 30
		},
		order = "g-c-c"
	}
})
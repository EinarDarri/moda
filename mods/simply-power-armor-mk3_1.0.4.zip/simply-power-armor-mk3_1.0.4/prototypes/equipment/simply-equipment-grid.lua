data:extend(
{
	{
		type = "equipment-grid",
		name = "simply-mk3-equipment-grid",
		width = 12,
		height = 12,
		equipment_categories = {"armor"}
	},
}
)

require("prototypes.item.simply-power-armor-mk3")
require("prototypes.equipment.simply-equipment-grid")
require("prototypes.recipe.simply-power-armor-mk3")
require("prototypes.technology.simply-power-armor-mk3")
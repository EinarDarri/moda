require("prototypes.functions")
require("prototypes.armor")
require("prototypes.grid")
require("prototypes.recipe")
require("prototypes.technology")

-- - {Armor specifications} - --

local tiers = {"mk3", "mk4", "mk5", "mk6", "ind1", "ind2", "ind3"}
local grids = {"10", "12", "14", "50", "12", "15", "20"}

for i, grid in pairs (grids) do
    data.raw["equipment-grid"][tiers[i].."_grid"].width = grid
    data.raw["equipment-grid"][tiers[i].."_grid"].height = grid
end

-- - {Displays every armor on the character when being used} - --

for i, tier in pairs (tiers) do
    if i<4 then
        local armor = "power-armor-"..tier
        table.insert(data.raw["character"]["character"].animations[3]["armors"], armor)
    else
        if i<7 then
            local armor = "industrial-armor-mk"..(i-3)
            table.insert(data.raw["character"]["character"].animations[3]["armors"], armor)
        end
    end
end

-- - {Ev modpack tweaks} - --

if settings.startup["equipment-division"].value == false then
    data.raw["energy-shield-equipment"]["energy-shield-equipment"].categories = {"armor", "ind_armor"}
    data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].categories = {"armor", "ind_armor"}
    data.raw["active-defense-equipment"]["personal-laser-defense-equipment"].categories = {"armor", "ind_armor"}
end

data.raw["night-vision-equipment"]["night-vision-equipment"].categories = {"armor", "ind_armor"}
data.raw["energy-shield-equipment"]["energy-shield-equipment"].categories = {"armor", "ind_armor"}
data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].categories = {"armor", "ind_armor"}
data.raw["battery-equipment"]["battery-equipment"].categories = {"armor", "ind_armor"}
data.raw["battery-equipment"]["battery-mk2-equipment"].categories = {"armor", "ind_armor"}
data.raw["solar-panel-equipment"]["solar-panel-equipment"].categories = {"armor", "ind_armor"}
data.raw["generator-equipment"]["fusion-reactor-equipment"].categories = {"armor", "ind_armor"}
data.raw["movement-bonus-equipment"]["exoskeleton-equipment"].categories = {"armor", "ind_armor"}
data.raw["roboport-equipment"]["personal-roboport-equipment"].categories = {"armor", "ind_armor"}
data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].categories = {"armor", "ind_armor"}
data.raw["belt-immunity-equipment"]["belt-immunity-equipment"].categories = {"armor", "ind_armor"}

-- - {Changes recipes when certain mods are installed} - --

if mods ["more-fusion-reactors"] then
    data.raw.recipe["power-armor-mk3"].ingredients[5] = {"fusion-reactor-mk2-equipment", 2}
    data.raw.recipe["power-armor-mk4"].ingredients[5] = {"fusion-reactor-mk3-equipment", 2}
    data.raw.recipe["power-armor-mk5"].ingredients[5] = {"fusion-reactor-mk4-equipment", 2}
    data.raw.recipe["power-armor-mk6"].ingredients[5] = {"fusion-reactor-mk5-equipment", 2}
    
    data.raw.recipe["industrial-armor-mk2"].ingredients[5] = {"fusion-reactor-mk3-equipment", 2}
    data.raw.recipe["industrial-armor-mk3"].ingredients[5] = {"fusion-reactor-mk5-equipment", 2}

    data.raw.technology["power-armor-mk3"].prerequisites[2] = "fusion-reactor-mk2-equipment"
    data.raw.technology["power-armor-mk4"].prerequisites[2] = "fusion-reactor-mk3-equipment"
    data.raw.technology["power-armor-mk5"].prerequisites[2] = "fusion-reactor-mk4-equipment"
    data.raw.technology["power-armor-mk6"].prerequisites[2] = "fusion-reactor-mk5-equipment"
end

if mods ["ev-personal-defence"] then
    data.raw.recipe["power-armor-mk4"].ingredients[6] = {"energy-shield-mk3-equipment", 4} -- (v4.0.0 Changes: -4)
    data.raw.recipe["power-armor-mk5"].ingredients[6] = {"energy-shield-mk4-equipment", 4} -- (v4.0.0 Changes: -1)
    data.raw.recipe["power-armor-mk6"].ingredients[6] = {"energy-shield-mk5-equipment", 4} -- (v4.0.0 Changes: +1)
    
    data.raw.recipe["industrial-armor-mk2"].ingredients[6] = {"energy-shield-mk3-equipment", 2}
    data.raw.recipe["industrial-armor-mk3"].ingredients[6] = {"energy-shield-mk5-equipment", 2}

    data.raw.technology["power-armor-mk4"].prerequisites[3] = "energy-shield-mk3-equipment"
    data.raw.technology["power-armor-mk5"].prerequisites[3] = "energy-shield-mk4-equipment"
    data.raw.technology["power-armor-mk6"].prerequisites[3] = "energy-shield-mk5-equipment"
end

-- - {If Both Ev: Fusion Reactors and Ev: Personal Defence are installed, nerfs recipes} - --

if mods ["more-fusion-reactors"] and mods ["ev-personal-defence"] then
    ---{Speed Modules Required}------------------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk3"].ingredients[6][2] = 15
    data.raw.recipe["power-armor-mk4"].ingredients[7][2] = 25
    data.raw.recipe["power-armor-mk5"].ingredients[7][2] = 20
    data.raw.recipe["power-armor-mk6"].ingredients[7][2] = 25
    
    data.raw.recipe["industrial-armor-mk3"].ingredients[7][2] = 10
    ---{Effectivity Modules Required}------------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk3"].ingredients[7][2] = 15
    data.raw.recipe["power-armor-mk4"].ingredients[8][2] = 25
    data.raw.recipe["power-armor-mk5"].ingredients[8][2] = 20
    data.raw.recipe["power-armor-mk6"].ingredients[8][2] = 25
    
    data.raw.recipe["industrial-armor-mk2"].ingredients[8][2] = 20
    data.raw.recipe["industrial-armor-mk3"].ingredients[8][2] = 25
    ---{Productivity Modules Required}-----------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk5"].ingredients[9][2] = 20
    data.raw.recipe["power-armor-mk6"].ingredients[9][2] = 25
    
    data.raw.recipe["industrial-armor-mk1"].ingredients[5][2] = 10
    data.raw.recipe["industrial-armor-mk2"].ingredients[7][2] = 20
    data.raw.recipe["industrial-armor-mk3"].ingredients[9][2] = 35
    ---{Blue Circuits Required}------------------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk2"].ingredients[2][2] = 25
    data.raw.recipe["power-armor-mk3"].ingredients[2][2] = 50
    data.raw.recipe["power-armor-mk4"].ingredients[2][2] = 75
    data.raw.recipe["power-armor-mk5"].ingredients[2][2] = 100
    data.raw.recipe["power-armor-mk6"].ingredients[2][2] = 125
    ---{Electric Engine Units Required}----------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk3"].ingredients[3][2] = 20
    data.raw.recipe["power-armor-mk4"].ingredients[3][2] = 30
    data.raw.recipe["power-armor-mk5"].ingredients[3][2] = 40
    data.raw.recipe["power-armor-mk6"].ingredients[3][2] = 50
    ---{Low density structures Required}---------------------------------------------------------------------------------
    data.raw.recipe["power-armor-mk3"].ingredients[4][2] = 10
    data.raw.recipe["power-armor-mk4"].ingredients[4][2] = 20
    data.raw.recipe["power-armor-mk5"].ingredients[4][2] = 30
    data.raw.recipe["power-armor-mk6"].ingredients[4][2] = 40
end
local aggro_tiers = {"mk3", "mk4", "mk5", "mk6"}
local industrial_tiers = {"ind1", "ind2", "ind3"}

-- - {Balancing} - --

data.raw["equipment-grid"]["small-equipment-grid"].width = 10
data.raw["equipment-grid"]["small-equipment-grid"].height = 10

data.raw["equipment-grid"]["medium-equipment-grid"].width = 11
data.raw["equipment-grid"]["medium-equipment-grid"].height = 11

-- - {Procedural Grids} - --

data:extend(
{
  {
    type = "equipment-category",
    name = "ind_armor"
  }
})

for i, tier in pairs (aggro_tiers) do
  data:extend({
    {
    type = "equipment-grid",
    name = tier.."_grid",
    width = 50,
    height = 50,
    equipment_categories = {"armor", "ind_armor"}
    },
  })
end

for i, tier in pairs (industrial_tiers) do
  data:extend({
    {
    type = "equipment-grid",
    name = tier.."_grid",
    width = 50,
    height = 50,
    equipment_categories = {"ind_armor"}
    },
  })
end
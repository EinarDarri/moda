data:extend({
    {
      type = "item-subgroup",
      name = "power-armors",
      group = "military",
      order = "a"
    },

})
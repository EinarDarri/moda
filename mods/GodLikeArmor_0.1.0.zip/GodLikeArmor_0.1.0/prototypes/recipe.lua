if not mods ["aai-industry"] then

data.raw.recipe["power-armor-mk2"].ingredients =
{
	{"power-armor", 1},
	{"processing-unit", 40},
	{"electric-engine-unit", 30},
	{"low-density-structure", 15},

	{"speed-module-2", 20},
	{"effectivity-module-2", 20}
}
end

data:extend(
{
  {
    type = "recipe",
    name = "power-armor-mk3",
    enabled = false,
    energy_required = 30,
	ingredients =
	{
		{"power-armor-mk2", 1},
		{"processing-unit", 60},
		{"electric-engine-unit", 40},
		{"low-density-structure", 30},

		{"fusion-reactor-equipment", 2},

		{"speed-module-2", 30},
		{"effectivity-module-2", 30}
	},
    result = "power-armor-mk3",
  },

  {
    type = "recipe",
    name = "power-armor-mk4",
    enabled = false,
    energy_required = 60,
	ingredients =
	{
		{"power-armor-mk3", 1},
		{"processing-unit", 80},
		{"electric-engine-unit", 50},
		{"low-density-structure", 40},

		{"fusion-reactor-equipment", 2},
		{"energy-shield-mk2-equipment", 10},

		{"speed-module-3", 35},
		{"effectivity-module-3", 35}
	},
    result = "power-armor-mk4",
  },

  {
    type = "recipe",
    name = "power-armor-mk5",
    enabled = false,
    energy_required = 90,
	ingredients =
	{
		{"power-armor-mk4", 1},
		{"processing-unit", 100},
		{"electric-engine-unit", 60},
		{"low-density-structure", 50},

		{"fusion-reactor-equipment", 4},
		{"energy-shield-mk2-equipment", 6}, -- (v4.0.0 Changes: -4)

		{"speed-module-3", 30},
		{"effectivity-module-3", 30},
		{"productivity-module-3", 30}
	},
    result = "power-armor-mk5",
  },

  {
    type = "recipe",
    name = "power-armor-mk6",
    enabled = false,
    energy_required = 120,
	ingredients =
	{
		{"power-armor-mk5", 1},
		{"processing-unit", 100},
		{"electric-engine-unit", 75},
		{"low-density-structure", 75},

		{"fusion-reactor-equipment", 4},
		{"energy-shield-mk2-equipment", 6}, -- (v4.0.0 Changes: -4)

		{"speed-module-3", 40},
		{"effectivity-module-3", 40},
		{"productivity-module-3", 40}
	},
    result = "power-armor-mk6",
  },

  -- Industrial armors --

  {
    type = "recipe",
    name = "industrial-armor-mk1",
    enabled = false,
    energy_required = 120,
	ingredients =
	{
	  {"power-armor", 1},
	  {"processing-unit", 60},
	  {"electric-engine-unit", 20},
	  {"low-density-structure", 10},

	  {"productivity-module-2", 20},
	  {"effectivity-module-2", 20}
	},
    result = "industrial-armor-mk1",
  },

  {
    type = "recipe",
    name = "industrial-armor-mk2",
    enabled = false,
    energy_required = 120,
	ingredients =
	{
	  {"industrial-armor-mk1", 1},
	  {"processing-unit", 100},
	  {"electric-engine-unit", 40},
	  {"low-density-structure", 25},

	  {"fusion-reactor-equipment", 2}, -- (v4.0.0 Changes: -1)
	  {"energy-shield-mk2-equipment", 2},

	  {"productivity-module-3", 35},
	  {"effectivity-module-3", 35}
	},
    result = "industrial-armor-mk2",
  },

  {
    type = "recipe",
    name = "industrial-armor-mk3",
    enabled = false,
    energy_required = 120,
	ingredients =
	{
	  {"industrial-armor-mk2", 1},
	  {"processing-unit", 150},
	  {"electric-engine-unit", 50},
	  {"low-density-structure", 50},

	  {"fusion-reactor-equipment", 4},
	  {"energy-shield-mk2-equipment", 2},

	  {"speed-module-3", 30},
	  {"effectivity-module-3", 30},
	  {"productivity-module-3", 50}
  },
    result = "industrial-armor-mk3",
  },

})
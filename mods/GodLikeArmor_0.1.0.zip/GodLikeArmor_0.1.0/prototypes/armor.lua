mod_name = "__GodLikeArmor__"

data.raw["armor"]["power-armor-mk2"].icon = mod_name.."/graphics/icons/power-armor-mk2.png"

data:extend(
{
  {
    type = "armor",
    name = "power-armor-mk3",
    icon = mod_name.."/graphics/icons/power-armor-mk3.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 99, -- +15 -- (Buff/Nerf that came in version 4.0.0)
        percent = 99
      },
      {
        type = "explosion",
        decrease = 99,
        percent = 99
      },
      {
        type = "fire",
        decrease = 99, -- +10 --
        percent = 99 -- -5% --
      },
      {
        type = "physical",
        decrease = 99, -- +10 --
        percent = 99
      }
    },
    subgroup = "armor",
    order = "eb[power-armor-mk3]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk3_grid",
    inventory_size_bonus = 35 -- -5 --
  },
  
  {
    type = "armor",
    name = "power-armor-mk4",
    icon = mod_name.."/graphics/icons/power-armor-mk4.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 40, -- +15 --
        percent = 80 -- +5% --
      },
      {
        type = "explosion",
        decrease = 100, -- +25 --
        percent = 60
      },
      {
        type = "fire",
        decrease = 25, -- +15 --
        percent = 75
      },
      {
        type = "physical",
        decrease = 37.5, -- +12.5 --
        percent = 55 -- +5% --
      }
    },
    subgroup = "armor",
    order = "ec[power-armor-mk4]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk4_grid",
    inventory_size_bonus = 40 -- -10 --
  },
  
  {
    type = "armor",
    name = "power-armor-mk5",
    icon = mod_name.."/graphics/icons/power-armor-mk5.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 75, -- +25 --
        percent = 80 -- +5% --
      },
      {
        type = "explosion",
        decrease = 100, -- +25 --
        percent = 70 -- -5% --
      },
      {
        type = "fire",
        decrease = 50, -- +25 --
        percent = 75
      },
      {
        type = "physical",
        decrease = 50,
        percent = 60 -- +10% --
      }
    },
    subgroup = "armor",
    order = "ed[power-armor-mk5]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk5_grid",
    inventory_size_bonus = 45 -- -15 --
  },
  
  {
    type = "armor",
    name = "power-armor-mk6",
    icon = mod_name.."/graphics/icons/power-armor-mk6.png",
    icon_size = 64, icon_mipmaps = 4,
    resistances =
    {
      {
        type = "acid",
        decrease = 150, -- +75 --
        percent = 99 -- +5% --
      },
      {
        type = "explosion",
        decrease = 150, -- +50 --
        percent = 99
      },
      {
        type = "fire",
        decrease = 75, -- +25 --
        percent = 99
      },
      {
        type = "physical",
        decrease = 75,
        percent = 99 -- +25% --
      }
    },
    subgroup = "armor",
    order = "ef[power-armor-mk5]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "mk6_grid",
    inventory_size_bonus = 50 -- -20 --
  },
  
})

-- Industrial Armors --

data:extend{
  {
    type = "armor",
    name = "industrial-armor-mk1",
    localised_name = "Industrial armor",
    icon = mod_name.."/graphics/icons/industrial-armor.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 0,
        percent = 25
      },
      {
        type = "explosion",
        decrease = 50,
        percent = 25
      },
      {
        type = "fire",
        decrease = 0,
        percent = 50
      },
      {
        type = "physical",
        decrease = 17.5,
        percent = 25
      }
    },
    subgroup = "armor",
    order = "eaa[industrial-armor]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind1_grid",
    inventory_size_bonus = 40,
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
  
  {
    type = "armor",
    name = "industrial-armor-mk2",
    localised_name = "Industrial armor Mk2",
    icon = mod_name.."/graphics/icons/industrial-armor-mk2.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 12.5,
        percent = 37.5
      },
      {
        type = "explosion",
        decrease = 75,
        percent = 37.5
      },
      {
        type = "fire",
        decrease = 5,
        percent = 62.5
      },
      {
        type = "physical",
        decrease = 17.5,
        percent = 37.5
      }
    },
    subgroup = "armor",
    order = "eca[industrial-armor-mk2]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind2_grid",
    inventory_size_bonus = 60,
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
  
  {
    type = "armor",
    name = "industrial-armor-mk3",
    localised_name = "Industrial armor Mk3",
    icon = mod_name.."/graphics/icons/industrial-armor-mk3.png",
    icon_size = 64,
    resistances =
    {
      {
        type = "acid",
        decrease = 25,
        percent = 50
      },
      {
        type = "explosion",
        decrease = 100,
        percent = 50
      },
      {
        type = "fire",
        decrease = 10,
        percent = 75
      },
      {
        type = "physical",
        decrease = 25,
        percent = 50
      }
    },
    subgroup = "armor",
    order = "efa[industrial-armor-mk3]",
    stack_size = 1,
    infinite = true,
    equipment_grid = "ind3_grid",
    inventory_size_bonus = 80,
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1}
  },
}
mod_name = "__GodLikeArmor__"

data.raw["technology"]["power-armor-mk2"].icon = mod_name.."/graphics/technology/power-armor-mk2.png"
data.raw["technology"]["power-armor-mk2"].effects[100] = -- Yeah no problems with mod compatibilities this time I'm sure of it --
{
  type = "unlock-recipe",
  recipe = "industrial-armor-mk1"
}

data:extend(
{

  {
    type = "technology",
    name = "power-armor-mk3",
    icon = mod_name.."/graphics/technology/power-armor-mk3.png",
    localised_description = {"technology-description.power-armor-3"},
	  icon_size = 256, icon_mipmaps = 4,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk3"
      }
    },
    prerequisites =
    {
      "power-armor-mk2",
      "fusion-reactor-equipment"
    },
    unit =
    {
      count = 600,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"utility-science-pack", 1}
      },
      time = 45
    },
    order = "g-c-ca"
  },
  {
    type = "technology",
    name = "power-armor-mk4",
    icon = mod_name.."/graphics/technology/power-armor-mk4.png",
    localised_description = {"technology-description.power-armor-4"},
	  icon_size = 256, icon_mipmaps = 4,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk4"
      },
      {
        type = "unlock-recipe",
        recipe = "industrial-armor-mk2"
      }
    },
    prerequisites =
    {
      "power-armor-mk3",
      "fusion-reactor-equipment",
      "energy-shield-mk2-equipment",
      "effectivity-module-3",
      "speed-module-3"
    },
    unit =
    {
      count = 800,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"chemical-science-pack", 2},
        {"military-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    },
    order = "g-c-cb"
  },
  {
    type = "technology",
    name = "power-armor-mk5",
    icon = mod_name.."/graphics/technology/power-armor-mk5.png",
    localised_description = {"technology-description.power-armor-5"},
	  icon_size = 256, icon_mipmaps = 4,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk5"
      }
    },
    prerequisites =
    {
      "power-armor-mk4",
      "fusion-reactor-equipment",
      "energy-shield-mk2-equipment",
      "productivity-module-3"
    },
    unit =
    {
      count = 1000,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"chemical-science-pack", 2},
        {"military-science-pack", 2},

        {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
        {"utility-science-pack", 1},
      },
      time = 75
    },
    order = "g-c-cc"
  },
  {
    type = "technology",
    name = "power-armor-mk6",
    icon = mod_name.."/graphics/technology/power-armor-mk6.png",
    localised_description = {"technology-description.power-armor-5"},
	  icon_size = 256, icon_mipmaps = 4,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "power-armor-mk6"
      },
      {
        type = "unlock-recipe",
        recipe = "industrial-armor-mk3"
      }
    },
    prerequisites =
    {
      "power-armor-mk5",
      "fusion-reactor-equipment",
      "energy-shield-mk2-equipment",
      "space-science-pack"
    },
    unit =
    {
      count = 1500,
      ingredients =
      {
        {"automation-science-pack", 2},
        {"logistic-science-pack", 2},
        {"chemical-science-pack", 2},
        {"military-science-pack", 2},
        
        {"production-science-pack", 1}, -- (v4.0.0 Changes: Introduced)
        {"utility-science-pack", 2},
        {"space-science-pack", 1},
      },
      time = 90
    },
    order = "g-c-cd"
  }

})
data:extend(
{
  {
    type = "bool-setting",
    name = "equipment-division",
    setting_type = "startup",
    default_value = true
  }
})
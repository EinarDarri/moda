for index, force in pairs(game.forces) do
  local technologies = force.technologies
  local recipes = force.recipes

  recipes["industrial-armor-mk1"].enabled = technologies["power-armor-mk2"].researched
  recipes["industrial-armor-mk2"].enabled = technologies["power-armor-mk4"].researched
  recipes["industrial-armor-mk3"].enabled = technologies["power-armor-mk6"].researched

  if technologies["power-armor-mk2"].researched then
    recipes["industrial-armor-mk1"].enabled = true
  end
  if technologies["power-armor-mk4"].researched then
    recipes["industrial-armor-mk2"].enabled = true
  end
  if technologies["power-armor-mk6"].researched then
    recipes["industrial-armor-mk3"].enabled = true
  end
end
local med_pole=table.deepcopy(data.raw["electric-pole"]["medium-electric-pole"])
local big_pole=table.deepcopy(data.raw["electric-pole"]["big-electric-pole"])
local sub_pole=table.deepcopy(data.raw["electric-pole"]["substation"])

local integration_patch_render_layer = "decorative"

med_pole.name = "slp-dec-med-pole"
med_pole.icon = "__slp-underground-poles__/graphics/md-icon.png"
med_pole.icon_mipmaps = 1
med_pole.minable = {mining_time = 0.5, result = "slp-dec-med-pole"}
med_pole.drawing_box = {{-0.5, -0.5}, {0.5, 0.5}}
med_pole.draw_copper_wires=false
med_pole.draw_circuit_wires=settings.startup["ds-show-circuit"].value
med_pole.integration_patch =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/pole.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.122,
        },
        {
          filename = "__slp-underground-poles__/graphics/pole-shadow.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.122,
          draw_as_shadow = true,
        }
	}}
med_pole.pictures =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/empty.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.122,
          direction_count = 1,
        }
	}}
med_pole.connection_points =
    {
      {
        shadow =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        },
        wire =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        }
      }
    }
med_pole.collision_mask = {"water-tile","colliding-with-tiles-only"}
--med_pole.collision_box =  {{0,0},{0,0}}
med_pole.integration_patch_render_layer = integration_patch_render_layer

big_pole.name = "slp-dec-big-pole"
big_pole.icon = "__slp-underground-poles__/graphics/bp-icon.png"
big_pole.icon_mipmaps = 1
big_pole.minable = {mining_time = 0.5, result = "slp-dec-big-pole"}
big_pole.drawing_box = {{-1, -1}, {1, 1}}
big_pole.draw_copper_wires=false
big_pole.draw_circuit_wires=settings.startup["ds-show-circuit"].value
big_pole.integration_patch =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/pole.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
        },
        {
          filename = "__slp-underground-poles__/graphics/pole-shadow.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
          draw_as_shadow = true,
        }
	}}
big_pole.pictures =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/empty.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
          direction_count = 1,
        }
	}}
big_pole.connection_points =
    {
      {
        shadow =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        },
        wire =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        }
      }
    }
big_pole.collision_mask = {"water-tile","colliding-with-tiles-only"}
--big_pole.collision_box =  {{0,0},{0,0}}
big_pole.integration_patch_render_layer = integration_patch_render_layer
big_pole.fast_replaceable_group = "big-electric-pole"

sub_pole.name = "slp-dec-sub-pole"
sub_pole.icon = "__slp-underground-poles__/graphics/sb-icon.png"
sub_pole.icon_mipmaps = 1
sub_pole.minable = {mining_time = 0.5, result = "slp-dec-sub-pole"}
sub_pole.drawing_box = {{-1, -1}, {1, 1}}
sub_pole.draw_copper_wires=false
sub_pole.draw_circuit_wires=settings.startup["ds-show-circuit"].value
sub_pole.integration_patch =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/sub-pole.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
        },
        {
          filename = "__slp-underground-poles__/graphics/pole-shadow.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
          draw_as_shadow = true,
        }
	}}
sub_pole.pictures =
    {
      layers =
      {
        {
          filename = "__slp-underground-poles__/graphics/empty.png",
          priority = "low",
          width = 256,
          height = 256,
		  scale = 0.23,
          direction_count = 1,
        }
	}}
sub_pole.connection_points =
    {
      {
        shadow =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        },
        wire =
        {
          copper = util.by_pixel_hr(0, 0),
          red = util.by_pixel_hr(0, 0),
          green = util.by_pixel_hr(0, 0)
        }
      }
    }
sub_pole.collision_mask = {"water-tile","colliding-with-tiles-only"}
sub_pole.integration_patch_render_layer = integration_patch_render_layer
sub_pole.fast_replaceable_group = "substation-electric-pole"

data:extend({
-- Items
	{
		type = "item",
		name = "slp-dec-med-pole",
		icon = "__slp-underground-poles__/graphics/md-icon.png",
		icon_size = 64,
		subgroup = "energy-pipe-distribution",
		order = "a[energy]-bb[medium-electric-pole]",
		place_result = "slp-dec-med-pole",
		stack_size = 50
	},
	{
		type = "item",
		name = "slp-dec-big-pole",
		icon = "__slp-underground-poles__/graphics/bp-icon.png",
		icon_size = 64,
		subgroup = "energy-pipe-distribution",
		order = "a[energy]-cb[big-electric-pole]",
		place_result = "slp-dec-big-pole",
		stack_size = 50
	},
	{
		type = "item",
		name = "slp-dec-sub-pole",
		icon = "__slp-underground-poles__/graphics/sb-icon.png",
		icon_size = 64,
		subgroup = "energy-pipe-distribution",
		order = "a[energy]-db[substation]",
		place_result = "slp-dec-sub-pole",
		stack_size = 50
	},

--Recipe
	{
		type = "recipe",
		name = "slp-dec-med-pole",
		enabled = "false",
		ingredients = 
		{
			{"medium-electric-pole",2},
			{"copper-plate",10}
		},
		result = "slp-dec-med-pole"
	},
	{
		type = "recipe",
		name = "slp-dec-big-pole",
		enabled = "false",
		ingredients = 
		{
			{"big-electric-pole",2},
			{"copper-plate",30}
		},
		result = "slp-dec-big-pole"
	},
	{
		type = "recipe",
		name = "slp-dec-sub-pole",
		enabled = "false",
		ingredients = 
		{
			{"substation",2},
			{"copper-plate",20},
			{"steel-plate",10}
		},
		result = "slp-dec-sub-pole"
	},
	
	med_pole,
	big_pole,
	sub_pole,
})
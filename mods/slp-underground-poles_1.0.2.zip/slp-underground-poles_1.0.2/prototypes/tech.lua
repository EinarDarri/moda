data:extend
({
    {
		type = "technology",
		name = "slp-underground-poles",
		icon = "__slp-underground-poles__/graphics/pole.png",
		icon_size = 256,
		prerequisites = {"electric-energy-distribution-1"},
		effects = {
			{type = "unlock-recipe", recipe = "slp-dec-med-pole"},
			{type = "unlock-recipe", recipe = "slp-dec-big-pole"},
		},
		unit = {
			count = 240,
			ingredients =
			{{"automation-science-pack", 1},{"logistic-science-pack", 1}},
			time = 40
		},
		order = "a-b",
	},
	{
		type = "technology",
		name = "slp-underground-sub",
		icon = "__slp-underground-poles__/graphics/sub-pole.png",
		icon_size = 256,
		prerequisites = {"slp-underground-poles","electric-energy-distribution-2"},
		effects = {
			{type = "unlock-recipe", recipe = "slp-dec-sub-pole"},
		},
		unit = {
			count = 200,
			ingredients =
			{{"automation-science-pack", 1},{"logistic-science-pack", 1},{"chemical-science-pack", 1}},
			time = 40
		},
		order = "a-b",
	},
})
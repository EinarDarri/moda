data:extend({
    {
        type = "bool-setting",
        name = "ds-show-circuit",
        setting_type = "startup",
        default_value = false
    }
})

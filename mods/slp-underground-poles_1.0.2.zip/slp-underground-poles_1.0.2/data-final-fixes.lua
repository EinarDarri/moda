data.raw["electric-pole"]["big-electric-pole"].fast_replaceable_group = "big-electric-pole"
data.raw["electric-pole"]["substation"].fast_replaceable_group = "substation-electric-pole"

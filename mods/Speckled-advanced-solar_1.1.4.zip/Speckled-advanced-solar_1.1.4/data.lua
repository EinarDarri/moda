require("prototypes.solar-panel")
require("prototypes.accumulator")
local migration = require("__flib__.migration")

local commons = require("scripts.commons")

local prefix = commons.prefix
local tools = require("scripts.tools")
local editor = require("scripts.editor")
local inspectlib = require("scripts.inspect")

local debug = tools.debug
local cdebug = tools.cdebug
local get_vars = tools.get_vars
local strip = tools.strip

-----------------------------------------------------

local processor_name = commons.processor_name
local processor_name_1x1 = commons.processor_name_1x1
local processor_pattern = commons.processor_pattern

local iopoint_name = commons.iopoint_name
local epole_name = prefix .. "-epole"
local accu_name = prefix .. "-accu"

local iopoint_with_alt = settings.startup["compaktcircuit-iopoint_with_alt"].value

local iopoint_default_color = commons.get_color(settings.startup["compaktcircuit-iopoint_default_color"].value,
	{ 0, 1, 0,
		1 })
local iopoint_connected_color = commons.get_color(settings.startup["compaktcircuit-iopoint_connected_color"].value,
	{ 1, 0, 0, 1 })
local iopoint_disconnected_color = commons.get_color(settings.startup["compaktcircuit-iopoint_disconnected_color"].value
	, { 1, 1, 0, 1 })


local mine_processor_as_tags_setting = prefix .. "-mine_processor_as_tags"

commons.entities_to_destroy = tools.table_merge
{ commons.packed_entities, { iopoint_name, epole_name, accu_name, commons.device_name } }

local function find_processor(entry)

	local processors = entry.surface.find_entities_filtered { name = { processor_name, processor_name_1x1 },
		position = entry.position }
	if #processors >= 1 then
		return processors[1]
	end
	return nil
end

local function create_iopoint_position(iopoint_positions, x1, y1, count, xi, yi)
	for i = 1, count do
		table.insert(iopoint_positions, { x = x1, y = y1 })
		x1 = x1 + xi
		y1 = y1 + yi
	end
end

local iopoint_positions_2x2 = {}
create_iopoint_position(iopoint_positions_2x2, -0.8, 0.8, 5, 0.4, 0)
create_iopoint_position(iopoint_positions_2x2, 0.8, 0.4, 3, 0.0, -0.4)
create_iopoint_position(iopoint_positions_2x2, 0.8, -0.8, 5, -0.4, 0)
create_iopoint_position(iopoint_positions_2x2, -0.8, -0.4, 3, 0.0, 0.4)

local iopoint_ranges_2x2 = {

	[defines.direction.north] = { { index = 1, count = 16 } },
	[defines.direction.east] = { { index = 13, count = 4 }, { index = 1, count = 12 } },
	[defines.direction.south] = { { index = 9, count = 8 }, { index = 1, count = 8 } },
	[defines.direction.west] = { { index = 5, count = 12 }, { index = 1, count = 4 } },

}

local coord_1x1 = 0.3

local iopoint_positions_1x1 = {
	{ x = 0, y = coord_1x1 },
	{ x = coord_1x1, y = 0 },
	{ x = 0, y = -coord_1x1 },
	{ x = -coord_1x1, y = 0 }
}

local iopoint_ranges_1x1 = {
	[defines.direction.north] = { { index = 1, count = 4 } },
	[defines.direction.east] = { { index = 4, count = 1 }, { index = 1, count = 3 } },
	[defines.direction.south] = { { index = 3, count = 2 }, { index = 1, count = 2 } },
	[defines.direction.west] = { { index = 2, count = 3 }, { index = 1, count = 1 } },
}



local function init_procinfo(procinfo)
	local processor = procinfo.processor
	if not processor.valid then return end
	local position = processor.position
	local x = position.x
	local y = position.y
	local surface = processor.surface
	local iopoints = {}

	-- create device for consumption
	local entries = surface.find_entities_filtered { name = commons.device_name, position = processor.position, radius = 0.2 }
	local entry
	if #entries == 1 then
		entry = entries[1]
	else
		entry = processor.surface.create_entity { name = commons.device_name, position = processor.position,
			force = processor.force }
		entry.destructible = false
	end

	local xradius, yradius = tools.get_radius(processor)
	local area = { { x - xradius, y - yradius }, { x + xradius, y + yradius } }
	local ghosts = surface.find_entities_filtered { name = "entity-ghost", ghost_name = iopoint_name, area = area }
	for _, g in pairs(ghosts) do
		g.silent_revive { raise_revive = true }
	end

	local find_count = 0

	local ranges, positions
	if processor.name == processor_name then
		ranges = iopoint_ranges_2x2[processor.direction]
		positions = iopoint_positions_2x2
	else
		ranges = iopoint_ranges_1x1[processor.direction]
		positions = iopoint_positions_1x1
	end

	for _, range in ipairs(ranges) do
		for index = range.index, range.index + range.count - 1 do
			local x1 = x + positions[index].x
			local y1 = y + positions[index].y
			area = { { x1 - 0.05, y1 - 0.05 }, { x1 + 0.05, y1 + 0.05 } }
			local point
			local points = surface.find_entities_filtered { name = iopoint_name, area = area }
			if #points == 0 then
				point = surface.create_entity { name = iopoint_name, position = { x1, y1 }, force = processor.force }
			else
				point = points[1]
				find_count = find_count + 1
			end
			rendering.draw_circle { color = iopoint_default_color, filled = false, target = point, surface = surface,
				radius = 0.05,
				width = 1, only_in_alt_mode = iopoint_with_alt }
			point.destructible = false
			point.minable = false
			table.insert(iopoints, point)
		end
	end

	procinfo.iopoints = iopoints
	processor.rotatable = false
	procinfo.draw_version = 1
	if procinfo.circuits then
		procinfo.is_packed = true
		editor.create_packed_circuit(procinfo)
	end
end

local function on_build(entity, e)
	if not entity or not entity.valid then return end

	local name = entity.name
	if string.find(name, processor_pattern) then

		local procinfo = editor.get_procinfo(entity, true)
		local tags = e.tags
		if not tags then
			tags = e.stack and e.stack.is_item_with_tags and e.stack.tags
		end

		if tags then
			procinfo.circuits = tags.circuits and game.json_to_table(tags.circuits)
			procinfo.model = tags.model
			procinfo.is_packed = true
		end

		init_procinfo(procinfo)
	end
end

local function on_robot_built(ev)
	local entity = ev.created_entity

	on_build(entity, ev)
end

local function on_script_built(ev)
	local entity = ev.entity

	on_build(entity, ev)
end

local function on_script_revive(ev)
	local entity = ev.entity

	on_build(entity, ev)
end

local function on_player_built(e)
	local entity = e.created_entity

	on_build(entity, e)
end

local function destroy_processor(processor)

	local procinfo = global.procinfos[processor.unit_number]
	if procinfo then
		local surface_name = editor.get_surface_name(procinfo.processor)
		if game.surfaces[surface_name] then
			game.delete_surface(surface_name)
		end
		global.surface_map[surface_name] = nil

		tools.destroy_entities(processor, commons.entities_to_destroy)
		global.procinfos[processor.unit_number] = nil
	end
	return procinfo
end

local function on_mined(e)
	local entity = e.entity

	if not entity or not entity.valid then return end

	-- debug("mine:" .. entity.name)
	if string.find(entity.name, processor_pattern) then


		local procinfo = destroy_processor(entity)

		if not settings.global[mine_processor_as_tags_setting].value then return end

		if e.name == defines.events.on_player_mined_entity and procinfo and
			procinfo.circuits and #procinfo.circuits > 0 then

			local buffer = e.buffer
			if not buffer then return end

			buffer.clear()
			buffer.insert { name = commons.processor_with_tags, count = 1 }
			buffer[1].set_tag("circuits", game.table_to_json(procinfo.circuits))
			if procinfo.model then
				buffer[1].set_tag("model", procinfo.model)
			end
		end
	elseif entity.name == iopoint_name then
		if e.buffer then
			e.buffer.clear()
		end
	end
end

local function on_player_mined_entity(ev)
	on_mined(ev)
end

local function on_gui_open_processor_panel(event)

	local player = game.players[event.player_index]
	local entity = event.entity
	if not entity or not entity.valid then
		return
	end

	if entity.name == commons.device_name then
		player.opened = nil
		local processor = find_processor(entity)
		if not processor then return end

		editor.edit_selected(player, processor)
	elseif entity.name == iopoint_name then
		player.opened = nil
	end
end

tools.on_event(defines.events.on_gui_opened, on_gui_open_processor_panel)

local build_filter = tools.table_merge {
	{
		{ filter = 'name', name = processor_name },
		{ filter = 'name', name = processor_name_1x1 }
	}
}


tools.on_event(defines.events.on_built_entity, on_player_built)
tools.on_event(defines.events.on_robot_built_entity, on_robot_built)
tools.on_event(defines.events.script_raised_built, on_script_built)
tools.on_event(defines.events.script_raised_revive, on_script_revive)

local mine_filter = {
	{ filter = 'name', name = processor_name },
	{ filter = 'name', name = processor_name_1x1 },
	{ filter = 'name', name = iopoint_name },
	{ filter = 'name', name = commons.device_name }
}

tools.on_event(defines.events.on_player_mined_entity, on_player_mined_entity, mine_filter)
tools.on_event(defines.events.on_robot_mined_entity, on_mined, mine_filter)
tools.on_event(defines.events.on_entity_died, on_mined, mine_filter)
tools.on_event(defines.events.script_raised_destroy, on_mined, mine_filter)

local function set_processor_bp(bp, index, entity)
	local procinfo = global.procinfos[entity.unit_number]
	if procinfo and procinfo.circuits then
		bp.set_blueprint_entity_tags(index, {
			circuits = procinfo.circuits and game.table_to_json(procinfo.circuits),
			model = procinfo.model
		})
	end
end

local function register_mapping(bp, mapping, surface)
	local procinfos = global.procinfos
	if not procinfos or next(procinfos) == nil then return end

	local bp_count = bp.get_blueprint_entity_count()
	if #mapping ~= 0 then
		for index = 1, bp_count do
			local entity = mapping[index]
			if entity and entity.valid then
				if string.find(entity.name, processor_pattern) then
					set_processor_bp(bp, index, entity)
				elseif entity.name == commons.internal_iopoint_name then
					local procinfo = global.surface_map[entity.surface.name]
					if procinfo then
						for id, iopoint_info in pairs(procinfo.iopoint_infos) do
							if id == entity.unit_number then
								bp.set_blueprint_entity_tags(index, {
									label = iopoint_info.label,
									index = iopoint_info.index
								})
								break
							end
						end
					end
				end
			end
		end
	elseif bp_count > 0 then
		local bp_entities = bp.get_blueprint_entities()
		for index = 1, bp_count do
			local entity = bp_entities[index]
			if string.find(entity.name, processor_pattern) then
				local entities = surface.find_entities_filtered { name = { processor_name, processor_name_1x1 },
					position = entity.position, radius = 0.1 }
				if #entities > 0 then
					local processor = entities[1]
					set_processor_bp(bp, entity.entity_number, processor)
				end
			elseif entity.name == commons.internal_iopoint_name then
				local procinfo = global.surface_map[surface.name]
				if procinfo then
					local entities = surface.find_entities_filtered { name = entity.name, position = entity.position, radius = 0.1 }
					if #entities > 0 then
						local unit_number = entities[1].unit_number
						for id, iopoint_info in pairs(procinfo.iopoint_infos) do
							if id == unit_number then
								bp.set_blueprint_entity_tags(index, {
									label = iopoint_info.label,
									index = iopoint_info.index
								})
								break
							end
						end
					end
				end
			end
		end
	end
end

local function on_register_bp(e)

	local player = game.get_player(e.player_index)
	local vars = tools.get_vars(player)
	if e.gui_type == defines.gui_type.item
		and e.item
		and e.item.is_blueprint
		and e.item.is_blueprint_setup()
		and player.cursor_stack
		and player.cursor_stack.valid_for_read
		and player.cursor_stack.is_blueprint
		and not player.cursor_stack.is_blueprint_setup()
	then
		vars.previous_bp = { blueprint = e.item, tick = e.tick }
	else
		vars.previous_bp = nil
	end
end

local function get_bp_to_setup(player)

	-- normal drag-select
	local bp = player.blueprint_to_setup
	if bp
		and bp.valid_for_read
		and bp.is_blueprint_setup() then
		return bp
	end

	-- alt drag-select (skips configuration dialog)
	bp = player.cursor_stack
	if bp
		and bp.valid_for_read
		and bp.is_blueprint
		and bp.is_blueprint_setup() then

		while bp.is_blueprint_book do
			bp = bp.get_inventory(defines.inventory.item_main)[bp.active_index]
		end
		return bp
	end

	-- update of existing blueprint
	local previous_bp = get_vars(player).previous_bp
	if previous_bp
		and previous_bp.tick == game.tick
		and previous_bp.blueprint
		and previous_bp.blueprint.valid_for_read
		and previous_bp.blueprint.is_blueprint_setup() then
		return previous_bp.blueprint
	end
end

tools.on_event(defines.events.on_player_setup_blueprint, function(e)
	local player = game.players[e.player_index]
	local mapping = e.mapping.get()
	local bp = get_bp_to_setup(player)
	if bp then register_mapping(bp, mapping, player.surface) end
end)

tools.on_event(defines.events.on_gui_closed, on_register_bp)

local function on_entity_cloned(ev)
	local source = ev.source
	local dest = ev.destination
	local source_name = source.name

	if string.find(source_name, processor_pattern) then

		local src_procinfo = editor.get_procinfo(source, true)
		local dst_procinfo = editor.get_procinfo(dest, true)

		dst_procinfo.circuits = src_procinfo.circuits
		dst_procinfo.model = src_procinfo.model
		if src_procinfo.is_packed then
			dst_procinfo.is_packed = true
		else
			dst_procinfo.is_packed = false
			if src_procinfo.surface then
				editor.disconnect_all_iopoints(src_procinfo)
				if src_procinfo.in_pole then
					src_procinfo.in_pole.disconnect_neighbour()
				end

				dst_procinfo.surface = src_procinfo.surface
				src_procinfo.surface = nil
				dst_procinfo.in_pole = src_procinfo.in_pole
				src_procinfo.in_pole = nil
				src_procinfo.is_packed = true

				local surface_name = editor.get_surface_name(dst_procinfo.processor)
				local src_surface_name = editor.get_surface_name(src_procinfo.processor)
				global.surface_map[src_surface_name] = nil
				global.surface_map[surface_name] = dst_procinfo

				dst_procinfo.iopoint_infos = tools.table_dup(src_procinfo.iopoint_infos)
				src_procinfo.iopoint_infos = {}

				init_procinfo(dst_procinfo)
				editor.connect_all_iopoints(dst_procinfo)
				editor.connect_energy(dst_procinfo)
				return
			end
		end
		init_procinfo(dst_procinfo)
	end
end

local clone_filter = tools.create_name_filter { { processor_name, processor_name_1x1 } }

script.on_event(defines.events.on_entity_cloned, on_entity_cloned, clone_filter)


local picker_dolly_blacklist = function()
	if not commons.debug_mode then
		if remote.interfaces["PickerDollies"] and remote.interfaces["PickerDollies"]["add_blacklist_name"] then
			for _, name in pairs({ processor_name, iopoint_name, processor_name_1x1 }) do
				remote.call("PickerDollies", "add_blacklist_name", name)
			end
		end
	end
end

local function on_init()
	global.procinfos = {}
	global.surface_map = {}
	picker_dolly_blacklist()
end

local function on_load()
	picker_dolly_blacklist()
end

script.on_init(on_init)
script.on_load(on_load)

local function on_entity_settings_pasted(e)
	local src = e.source
	local dst = e.destination

	if not src.valid or not dst.valid then return end

	if string.find(src.name, processor_pattern) and string.find(dst.name, processor_pattern) then
		local src_procinfo = editor.get_procinfo(src)
		local dst_procinfo = editor.get_procinfo(dst)

		editor.set_circuits(dst_procinfo, src_procinfo.circuits, src_procinfo.is_packed)
	end
end

tools.on_event(defines.events.on_entity_settings_pasted, on_entity_settings_pasted)


local function show_names(player, processor)

	if not player.mod_settings[prefix .. "-show-iopoint-name"].value then
		return
	end

	local procinfo = editor.get_procinfo(processor, false)
	if not procinfo then return end
	if not procinfo.iopoints then return end

	local position = processor.position
	local surface = processor.surface
	local ids = {}
	get_vars(player).id_names = ids

	local selection_box = processor.selection_box
	local width = selection_box.right_bottom.x - selection_box.left_top.x
	local scale = width / 2.5
	if procinfo.model then
		local model = procinfo.model
		local words = string.gmatch(procinfo.model, "%S+")
		local lines = {}
		local line = nil
		for w in string.gmatch(procinfo.model, "%S+") do
			if not line then
				line = w
			else
				if #line + #w + 1 >= 12 then
					table.insert(lines, line)
					line = w
				else
					line = line .. " " .. w
				end
			end
		end
		if line then
			table.insert(lines, line)
		end
		local lcount = #lines
		local hline = 0.22
		local y = -(lcount - 1) / 2 * hline
		for index, line in ipairs(lines) do
			local id = rendering.draw_text {
				text = line,
				surface = surface,
				target = processor,
				target_offset = { x = 0, y = y },
				alignment = "center",
				color = { 1, 1, 1, 0.8 },
				scale = 0.6 * scale,
				vertical_alignment = "middle"
			}
			table.insert(ids, id)
			y = y + hline
		end
	end

	for index, point in ipairs(procinfo.iopoints) do

		if procinfo.circuits then

			local info
			for _, c in pairs(procinfo.circuits) do
				if c.name == commons.internal_iopoint_name and c.index == index then
					info = c
					break
				end
			end
			if info then
				local io_position = point.position
				local dx = io_position.x - position.x
				local dy = io_position.y - position.y

				local label
				if info.label and info.label ~= "" then
					label = "(" .. tostring(index) .. "):" .. info.label
				else
					label = "(" .. tostring(index) .. ")"
				end

				local orientation, alignment, offset
				local delta = 0.20
				local sprite_orientation
				if math.abs(dx) >= math.abs(dy) then
					if dx >= 0 then
						offset = { delta, 0 }
						orientation = 0
						alignment = "left"
						sprite_orientation = 0
					else
						offset = { -delta, 0 }
						orientation = 0
						alignment = "right"
						sprite_orientation = 0.5
					end
				else
					if dy >= 0 then
						offset = { 0.0, delta }
						orientation = 0.25
						alignment = "left"
						sprite_orientation = 0.25
					else
						offset = { 0.0, -delta }
						orientation = 0.25
						alignment = "right"
						sprite_orientation = 0.75
					end

				end

				local id = rendering.draw_text { text = label,
					surface = surface,
					target = point,
					target_offset = offset,
					orientation = orientation,
					alignment = alignment,
					color = { 1, 1, 1, 1 },
					scale = 0.8,
					vertical_alignment = "middle"
				}
				table.insert(ids, id)

				local sprite_scale = 0.4
				local sprite_id = rendering.draw_sprite {
					surface = surface,
					sprite = prefix .. "-arrow",
					target = point,
					orientation = sprite_orientation,
					x_scale = sprite_scale * scale,
					y_scale = sprite_scale * scale

				}
				table.insert(ids, sprite_id)
			end
		end
	end

end

local function on_selected_entity_changed(e)
	local player = game.players[e.player_index]
	local selected = player.selected
	local vars = get_vars(player)

	if vars.id_names then
		for _, id in ipairs(vars.id_names) do rendering.destroy(id) end
		vars.id_names = nil
	end
	if vars.selected_id then
		rendering.destroy(vars.selected_id)
		vars.selected_id = nil
	end

	if selected ~= nil and selected.name == iopoint_name then

		local pos = selected.position
		local entities = selected.surface.find_entities_filtered {
			area = { { pos.x - 1, pos.y - 1 }, { pos.x + 1, pos.y + 1 } },
			name = { processor_name, processor_name_1x1 }
		}
		if #entities == 0 then
			return
		end

		local processor
		local procinfo
		local found_index
		for _, p in pairs(entities) do
			procinfo = editor.get_procinfo(p, false)
			if procinfo and procinfo.iopoints then 
				for index, point in pairs(procinfo.iopoints) do
					if point.unit_number == selected.unit_number then
						found_index = index
						break
					end
				end
				if found_index then
					processor = p
					break
				end
			end
		end
		if not found_index then return end

		local info = nil
		if procinfo.circuits then
			for _, c in pairs(procinfo.circuits) do
				if c.name == commons.internal_iopoint_name and c.index == found_index then
					info = c
					break
				end
			end
		end

		local label
		local color
		if info then
			if info.label and info.label ~= "" then
				label = "(" .. tostring(found_index) .. "):" .. info.label
			else
				label = "(" .. tostring(found_index) .. ")"
			end
			color = iopoint_connected_color
		else
			label = tostring(found_index)
			color = iopoint_disconnected_color
		end
		if vars.selected_id then
			rendering.set_text(vars.selected_id, label)
		else
			vars.selected_id = rendering.draw_text {
				text = label,
				surface = selected.surface,
				target = selected,
				color = color,
				only_in_alt_mode = false,
				alignment = "center",
				target_offset = { 0, -0.7 }
			}
		end
		return
	end

	if selected ~= nil and string.find(selected.name, processor_pattern) then
		inspectlib.show(player, selected)
		show_names(player, selected)
	else
		inspectlib.clear(player)
	end
end

tools.on_event(defines.events.on_selected_entity_changed, on_selected_entity_changed)


script.on_event(prefix .. "-click", function(event)

	local player = game.players[event.player_index]
	local selected = player.selected
	if selected and string.find(selected.name, processor_pattern) and player.is_cursor_empty() then
		editor.edit_selected(player, selected)
	end
end)

local function purge(player_index)

	log("Purge: on_configuration_changed")

	if not global.procinfos then return end
	local names = {}
	local missings = {}
	local founds = {}
	for _, procinfo in pairs(global.procinfos) do
		if not procinfo.processor or not procinfo.processor.valid then
			table.insert(missings, procinfo)
		else
			local name = editor.get_surface_name(procinfo.processor)
			names[name] = true
			table.insert(founds, procinfo)
		end
	end

	local todelete = {}
	for _, surface in pairs(game.surfaces) do
		local name = surface.name
		if string.sub(name, 1, 5) == 'proc_' then
			if not names[name] then
				table.insert(todelete, name)
			end
		end
	end

	for _, name in pairs(todelete) do
		game.delete_surface(name)
		global.surface_map[name] = nil
	end

	for _, procinfo in pairs(missings) do
		global.procinfos[procinfo.unit_number] = nil
	end

	local msg = "Purge: invalid=" .. #missings .. ", valid=" .. #founds .. ", invalid surface=" .. #todelete
	log(msg)
	if player_index then
		game.players[player_index].print(msg);
	end
end

local function migration_1_0_7(data)
	purge()

	if global.procinfos then
		for _, procinfo in pairs(global.procinfos) do
			if not procinfo.draw_version then
				for _, point in pairs(procinfo.iopoints) do
					rendering.draw_circle { color = iopoint_default_color, filled = false, target = point, surface = point.surface,
						radius = 0.05,
						width = 1, only_in_alt_mode = iopoint_with_alt }
				end
				procinfo.draw_version = 1
			end

			if procinfo.acc then
				if procinfo.surface and procinfo.surface.valid then
					editor.connect_energy(procinfo)
				end
			end
		end
	end
end

local regenerate_packed

local function migration_1_0_14(data)
	purge()
	regenerate_packed()
	for _, player in pairs(game.players) do
		if player.force.technologies[commons.prefix .. "-tech"] then
			player.force.recipes[commons.processor_name_1x1].enabled = true
		end
	end
end


local migrations_table = {

	["1.0.7"] = migration_1_0_7,
	["1.0.8"] = function()

		if not global.procinfos then return end
		for _, procinfo in pairs(global.procinfos) do
			local processor = procinfo.processor
			if processor and processor.valid then
				processor.direction = defines.direction.north
				processor.rotatable = false
			end
		end
	end,
	["1.0.14"] = migration_1_0_14
}

local function on_configuration_changed(data)
	migration.on_config_changed(data, migrations_table)
end

script.on_configuration_changed(on_configuration_changed)

local function all_pack(player_index)

	local player = game.players[player_index]
	local force = player.force
	local used = {}
	for _, player in pairs(game.players) do
		if player.surface then
			used[player.surface.name] = true
		end
	end

	local pack_count = 0
	for _, procinfo in pairs(global.procinfos) do
		if procinfo.processor and procinfo.processor.valid and procinfo.processor.force == force then

			local surface = procinfo.surface
			if surface and surface.valid and not used[surface.valid] then
				if not procinfo.is_packed then
					editor.set_packed(procinfo, true)
					editor.delete_surface(procinfo)
					pack_count = pack_count + 1
				end
			end
		end
	end

	game.print("Pack #=" .. pack_count)
end

regenerate_packed = function()

	local pack_count = 0
	for _, procinfo in pairs(global.procinfos) do
		if procinfo.processor and procinfo.processor.valid and procinfo.is_packed and not procinfo.surface then
			editor.regenerate_packed(procinfo)
			pack_count = pack_count + 1
		end
	end

	game.print("Pack #=" .. pack_count)
end


commands.add_command("compaktcircuit_purge", { "compaktcircuit_purge_cmd" }, function(e) purge(e.player_index) end)
commands.add_command("compaktcircuit_pack", { "compaktcircuit_pack" },
	function(e)
		all_pack(e.player_index)
	end)
commands.add_command("compaktcircuit_regenerate_packed", { "compaktcircuit_regenerate_packed" },
	function(e)
		regenerate_packed()
	end)

local function on_player_rotated_entity(e)
	local entity = e.entity
end

tools.on_event(defines.events.on_player_rotated_entity, on_player_rotated_entity)

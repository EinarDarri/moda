local commons = require("scripts.commons")

local prefix = commons.prefix
local tools = require("scripts.tools")

local debug = tools.debug
local cdebug = tools.cdebug
local get_vars = tools.get_vars
local strip = tools.strip

local editor = {}
local EDITOR_SIZE = 32
local iopoint_text_color = commons.get_color(settings.startup["compaktcircuit-iopoint_text_color"].value, { 0, 0, 1, 1 })

local internal_iopoint_name = commons.internal_iopoint_name
local allowed_name_map = {

    ["constant-combinator"] = prefix .. "-cc",
    ["decider-combinator"] = prefix .. "-dc",
    ["arithmetic-combinator"] = prefix .. "-ac",
    --[[
    ["big-electric-pole"] = prefix .. "-pole",
    ["small-electric-pole"] = prefix .. "-pole",
    ["medium-electric-pole"] = prefix .. "-pole",
    [internal_iopoint_name] = prefix .. "-pole",
    ["substation"] = prefix .. "-pole",
    --]]
    ["big-electric-pole"] = prefix .. "-cc",
    ["small-electric-pole"] = prefix .. "-cc",
    ["medium-electric-pole"] = prefix .. "-cc",
    [internal_iopoint_name] = prefix .. "-cc",
    ["substation"] = prefix .. "-cc",
    ["small-lamp"] = prefix .. "-lamp1"
}

local close_iopanel

local function close_editor_panel(player)
    local b = player.gui.left[prefix .. "-intern_panel"]
    if b then b.destroy() end
end

local function get_procinfo(processor, create)
    if not global.procinfos then global.procinfos = {} end
    local procinfo = global.procinfos[processor.unit_number]
    if not procinfo and create then
        procinfo = {
            processor = processor,
            unit_number = processor.unit_number,
            iopoints = {}, -- external io point
            iopoint_infos = {} -- map: unit_number of internal iopoint => information on point
        }
        global.procinfos[processor.unit_number] = procinfo
    end
    return procinfo
end

editor.get_procinfo = get_procinfo

function editor.get_surface_name(processor)
    return "proc_" .. processor.unit_number
end

---------------------------------------------------------

local function get_models(player, name)
    local force = player.force
    local map = {}
    for _, procinfo in pairs(global.procinfos) do
        if procinfo.processor and 
                procinfo.processor.valid and 
                procinfo.processor.force == force and
                procinfo.processor.name == name
                then
            local model = procinfo.model
            if model and model ~= "" then
                map[model] = true
            end
        end
    end

    local models = {}
    for model, _ in pairs(map) do
        table.insert(models, model)
    end
    table.sort(models)
    table.insert(models, 1, "---------------")
    return models
end

local function get_model_position(player, procinfo)
    local model = procinfo.model or ""
    local models = get_models(player, procinfo.processor.name)
    local selected_index = 1
    if model ~= "" then
        for index, m in ipairs(models) do
            if m == model then
                selected_index = index
                break
            end
        end
    end
    return models, selected_index
end

local internal_panel_name = prefix .. "-intern_panel"

function editor.create_editor_panel(player, procinfo)
    close_editor_panel(player)
    local frame = player.gui.left.add { type = "frame", direction = "vertical", name = internal_panel_name }
    local b = frame.add { type = "button", caption = { "button.exit_editor" }, name = prefix .. "-exit_editor" }
    b.style.width = 200
    b = frame.add { type = "button", caption = { "button.add_iopole" }, name = prefix .. "-add_iopole" }
    b.style.width = 200
    b = frame.add { type = "checkbox", state = procinfo.is_packed or false, caption = { "parameters.is_packed" },
        tooltip = { "tooltip.is_packed" }, name = prefix .. "-is_packed" }

    local models, selected_index = get_model_position(player, procinfo)
    local modelFlow = frame.add { type = "flow", direction = "horizontal", name = "model_flow" }
    modelFlow.add { type = "label", caption = { "label.model" } }
    local dp = modelFlow.add { type = "drop-down", name = prefix .. "-model_list", items = models,
        selected_index = selected_index }
    dp.style.width = 200

    local f
    f = modelFlow.add { type = "textfield", name = prefix .. "-model_name" }
    f.visible = false
    f.style.width = 200

    local modelButtonFlow
    local modelButtonFlow = frame.add { type = "flow", direction = "horizontal", name = "model_button_flow" }
    f = modelButtonFlow.add { type = "button", name = prefix .. "-new_model_button", caption = { "button.new_model" },
        tooltip = { "tooltip.new_model" } }
    f.style.width = 80
    f = modelButtonFlow.add { type = "button", name = prefix .. "-rename_button", caption = { "button.rename_model" },
        tooltip = { "tooltip.rename_model" } }
    f.style.width = 80
    b = modelButtonFlow.add { type = "button", caption = { "button.apply_model" }, tooltip = { "tooltip.apply_model" },
        name = prefix .. "-apply_model" }
    b.style.width = 80
    b = modelButtonFlow.add { type = "button", caption = { "button.import_model" }, tooltip = { "tooltip.import_model" },
        name = prefix .. "-import_model" }
    b.style.width = 80

    f = modelButtonFlow.add { type = "button", name = prefix .. "-ok_button", caption = { "button.ok" } }
    f.visible = false
    f.style.width = 160
    f = modelButtonFlow.add { type = "button", name = prefix .. "-cancel_button",
        caption = { "button.cancel" } }
    f.visible = false
    f.style.width = 160


end

local function get_model_flow(player)
    return tools.get_child(player.gui.left[internal_panel_name], "model_flow") or {}
end

local function get_model_button_flow(player)
    return tools.get_child(player.gui.left[internal_panel_name], "model_button_flow") or {}
end

local function set_label_mode(player, text_mode, action_mode, ok_text)

    local model_flow = get_model_flow(player)
    local model_button_flow = get_model_button_flow(player)

    model_flow[prefix .. "-model_list"].visible = not text_mode

    model_button_flow[prefix .. "-new_model_button"].visible = not action_mode
    model_button_flow[prefix .. "-rename_button"].visible = not action_mode
    model_button_flow[prefix .. "-apply_model"].visible = not action_mode
    model_button_flow[prefix .. "-import_model"].visible = not action_mode

    model_flow[prefix .. "-model_name"].visible = text_mode
    model_button_flow[prefix .. "-ok_button"].visible = action_mode
    model_button_flow[prefix .. "-cancel_button"].visible = action_mode
    if ok_text then
        model_button_flow[prefix .. "-ok_button"].caption = ok_text
    end
    if text_mode then
        model_flow[prefix .. "-model_name"].focus()
    end
end

local function add_model(player)

    local procinfo = global.surface_map[player.surface.name]
    local model_flow = get_model_flow(player)
    local model = model_flow[prefix .. "-model_name"].text
    if model == "" then
        procinfo.model = nil
    else
        procinfo.model = model
    end
    local models, index = get_model_position(player, procinfo)
    local cb = model_flow[prefix .. "-model_list"]
    cb.items = models
    cb.selected_index = index
end

local function import_model(player)
    local procinfo = global.surface_map[player.surface.name]
    if procinfo.model == nil then return end

    local model_procinfo = nil
    for _, p in pairs(global.procinfos) do
        if p ~= procinfo
            and p.model == procinfo.model
            and procinfo.processor
            and procinfo.processor.valid
            and procinfo.processor.force == player.force then
            model_procinfo = p
            break
        end
    end
    if not model_procinfo then
        return
    end

    editor.save_packed_circuits(model_procinfo)
    local position = player.position
    player.teleport { -EDITOR_SIZE / 2 + 1, -EDITOR_SIZE / 2 + 1 }
    editor.clean_surface(procinfo)
    procinfo.circuits = model_procinfo.circuits
    editor.restore_packed_circuits(procinfo)
    player.teleport(position)
end

local function rename_model(player)

    local procinfo = global.surface_map[player.surface.name]
    if procinfo.model == nil then return end

    local model_flow = get_model_flow(player)
    local new_model = model_flow[prefix .. "-model_name"].text
    if new_model == "" then return end

    local old_model = procinfo.model
    for _, p in pairs(global.procinfos) do
        if p.model == old_model
            and p.processor
            and p.processor.valid
            and p.processor.force == player.force then
            p.model = new_model
        end
    end

    local models, index = get_model_position(player, procinfo)
    local cb = model_flow[prefix .. "-model_list"]
    cb.items = models
    cb.selected_index = index
end

local function apply_model(player)

    local model_procinfo = global.surface_map[player.surface.name]
    if not model_procinfo.model then
        return
    end

    local force = player.force
    model_procinfo.circuits = editor.save_packed_circuits(model_procinfo)
    local count = 0
    for _, procinfo in pairs(global.procinfos) do
        if procinfo.processor
            and procinfo.processor.valid
            and procinfo.processor.force == force
            and procinfo ~= model_procinfo
            and procinfo.model == model_procinfo.model
        then
            editor.set_circuits(procinfo, model_procinfo.circuits, false)
            count = count + 1
        end
    end
    player.print({ "message.apply_to_processor", count })

end

local function execute_model_action(player)

    local model_action = get_vars(player).model_action
    set_label_mode(player, false, false)
    if model_action == "add" then
        add_model(player)
    elseif model_action == "rename" then
        rename_model(player)
    elseif model_action == "apply" then
        apply_model(player)
    elseif model_action == "import" then
        import_model(player)
    end
end

-----------------------------------------------------------------

tools.on_event(defines.events.on_gui_selection_state_changed, function(e)

    if e.element.name ~= prefix .. "-model_list" then return end

    local player = game.players[e.player_index]
    local procinfo = global.surface_map[player.surface.name]
    if e.element.selected_index == 1 then
        procinfo.model = nil
    else
        procinfo.model = e.element.items[e.element.selected_index]
    end
end)

tools.on_event(defines.events.on_gui_confirmed, function(e)

    if e.element.name ~= prefix .. "-model_name" then return end

    local player = game.players[e.player_index]
    execute_model_action(player)
end)

tools.on_gui_click(prefix .. "-new_model_button",
    function(e)
        local player = game.players[e.player_index]
        get_vars(player).model_action = "add"
        set_label_mode(player, true, true, { "button.new_model" })
    end
)


tools.on_gui_click(prefix .. "-rename_button",
    function(e)
        local player = game.players[e.player_index]

        local procinfo = global.surface_map[player.surface.name]
        if procinfo.model == nil then return end

        local model_flow = get_model_flow(player)
        model_flow[prefix .. "-model_name"].text = procinfo.model

        get_vars(player).model_action = "rename"
        set_label_mode(player, true, true, { "button.rename_model" })
    end
)

tools.on_gui_click(prefix .. "-import_model",
    function(e)
        local player = game.players[e.player_index]
        get_vars(player).model_action = "import"
        set_label_mode(player, false, true, { "button.import_model_confirm" })
    end
)

tools.on_gui_click(prefix .. "-apply_model", function(e)
    local player = game.players[e.player_index]
    get_vars(player).model_action = "apply"
    set_label_mode(player, false, true, { "button.apply_model_confirm" })
end)

tools.on_gui_click(prefix .. "-cancel_button",
    function(e)
        local player = game.players[e.player_index]
        set_label_mode(player, false, false)
    end
)

tools.on_gui_click(prefix .. "-ok_button",
    function(e)
        local player = game.players[e.player_index]
        execute_model_action(player)
    end
)

-----------------------------------------------------------------

function editor.edit_selected(player, processor)

    if not processor or not processor.valid then return end

    local procinfo = get_procinfo(processor, true)

    procinfo.origin_surface_name = player.surface.name
    procinfo.origin_surface_position = player.position
    procinfo.processor = processor

    local vars = get_vars(player)
    vars.procinfo = procinfo
    vars.processor = processor
    local surface = editor.get_or_create_surface(procinfo)

    if procinfo.is_packed then
        editor.restore_packed_circuits(procinfo)
    end

    local x = 0
    local y = 0
    local count = 0
    while true do
        local entities = surface.find_entities({ { x - 1, y - 1 }, { x + 1, y + 1 } })
        if #entities == 0 then
            break
        end
        x = x + 1
        if x > EDITOR_SIZE / 2 - 1 then
            x = -EDITOR_SIZE / 2 + 1
            y = y + 1
            if y > EDITOR_SIZE / 2 - 1 then
                y = -EDITOR_SIZE / 2 + 1
            end
        end
        count = count + 1
        if count > 1000 then
            break
        end
    end

    player.teleport({ x, y }, surface)
end

local function on_exit_editor(e)

    local player = game.players[e.player_index]
    close_iopanel(player)
    close_editor_panel(player)

    local surface = player.surface
    local vars = get_vars(player)
    local procinfo = vars.procinfo

    vars.is_standard_exit = true

    local origin_surface_name     = procinfo.origin_surface_name
    local origin_surface_position = procinfo.origin_surface_position

    local origin_surface = game.surfaces[origin_surface_name]
    if not origin_surface or not origin_surface.valid then
        origin_surface_name = "nauvis"
        origin_surface_position = { x = 0, y = 0 }
    end
    player.teleport(origin_surface_position, origin_surface_name)
end

local function on_gui_checked_state_changed(e)

    if not e.element or e.element.name ~= prefix .. "-is_packed" then return end
    local player = game.players[e.player_index]

    local surface = player.surface
    local vars = get_vars(player)
    local procinfo = vars.procinfo
    local new_packed = e.element.state
    editor.set_packed(procinfo, new_packed)
end

function editor.set_packed(procinfo, is_packed)

    if procinfo.is_packed == is_packed then return end
    procinfo.is_packed = is_packed
    if is_packed then
        editor.save_packed_circuits(procinfo)
        editor.disconnect_all_iopoints(procinfo)
        editor.create_packed_circuit(procinfo)
    else
        editor.destroy_packed_circuit(procinfo)
        editor.connect_all_iopoints(procinfo)
    end
end

function editor.regenerate_packed(procinfo)

    if not procinfo.is_packed then return end

    editor.create_packed_circuit(procinfo)
end


tools.on_event(defines.events.on_gui_checked_state_changed, on_gui_checked_state_changed)

local function on_add_pole(e)

    local player = game.players[e.player_index]
    local stack = player.cursor_stack
    if stack and stack.valid then

        if stack.count > 0 then

            if stack.name == internal_iopoint_name then return end

            local empty_stack = player.get_main_inventory().find_empty_stack()
            if empty_stack then
                empty_stack.transfer_stack(stack)
            else
                player.surface.spill_item_stack(player.position, { stack })
            end
            stack.clear()
        end

        player.cursor_ghost = internal_iopoint_name
    end
end

tools.on_gui_click(prefix .. "-exit_editor", on_exit_editor)
tools.on_gui_click(prefix .. "-add_iopole", on_add_pole)

---------------------------------------------------------------

function editor.get_or_create_surface(procinfo)

    if not global.surface_map then
        global.surface_map = {}
    end

    local surface_name = editor.get_surface_name(procinfo.processor)
    local surface = game.get_surface(surface_name)
    if surface and surface == procinfo.surface and surface.valid then
        return surface
    end

    if not surface or not surface.valid then
        surface = game.create_surface(surface_name, { width = EDITOR_SIZE, height = EDITOR_SIZE })

        surface.request_to_generate_chunks({ 0, 0 }, 8)
        surface.force_generate_chunk_requests()
        surface.destroy_decoratives({})

        local tiles = {}
        local tile_proto = prefix .. "-ground"
        if not game.tile_prototypes[tile_proto] then
            tile_proto = "refined-concrete"
        end

        for _, tile in ipairs(surface.find_tiles_filtered { position = { 0, 0 }, radius = EDITOR_SIZE + 2 }) do
            local position = tile.position
            if (math.abs(position.x) > EDITOR_SIZE / 2 or math.abs(position.y) > EDITOR_SIZE / 2) then
                table.insert(tiles, { name = "out-of-map", position = position })
            else
                table.insert(tiles, { name = tile_proto, position = position })
            end
        end

        surface.set_tiles(tiles)
    end


    procinfo.surface = surface
    global.surface_map[surface_name] = procinfo

    editor.clean_surface(procinfo)
    return surface
end

function editor.clean_surface(procinfo)
    for _, entity in ipairs(procinfo.surface.find_entities()) do
        if entity.type ~= "character" then
            entity.destroy()
        end
    end
    editor.connect_energy(procinfo)
end

---------------------------------------------------------------

function editor.connect_energy(procinfo)

    local processor = procinfo.processor
    local in_pole = procinfo.in_pole
    if not in_pole or not in_pole.valid then
        in_pole = procinfo.surface.create_entity { name = prefix .. "-energy_pole", position = { EDITOR_SIZE / 2 + 4, 4 },
            force = processor.force }
        procinfo.in_pole = in_pole
    end

    local generator = procinfo.generator
    if not generator or not generator.valid then
        generator = procinfo.surface.create_entity { name = prefix .. "-energy_source",
            position = { EDITOR_SIZE / 2 + 4, 10 },
            force = processor.force }
        procinfo.generator = generator
    end

    local energy_pole = procinfo.energ_pole
    if energy_pole and energy_pole.valid then
        energy_pole.destroy()
        procinfo.energ_pole = nil
    end

    local accu = procinfo.accu
    if accu and accu.valid then
        accu.destroy()
        procinfo.accu = nil
    end
end

---------------------------------------------------------------

close_iopanel = function(player)
    local panel = player.gui.left[prefix .. "-iopole_panel"]
    if panel then
        panel.destroy()
    end
end

---------------------------------------------------------------

function editor.connect_iopole(procinfo, iopole_info)

    local index = iopole_info.index
    if index <= 0 then return end
    local point = procinfo.iopoints[index]

    -- debug("Try connect to iopole: extern=" .. point.unit_number .. "=> internl=" .. iopole_info.entity.unit_number)
    local success1 = point.connect_neighbour({
        wire = defines.wire_type.green,
        target_entity = iopole_info.entity
    })
    local success2 = point.connect_neighbour({
        wire = defines.wire_type.red,
        target_entity = iopole_info.entity
    })
    if not success1 or not success2 then
        debug("Failed connect to iopole")
    end
end

---------------------------------------------------------------

function editor.connect_all_iopoints(procinfo)

    for _, iopoint_info in pairs(procinfo.iopoint_infos) do
        editor.connect_iopole(procinfo, iopoint_info)
    end
end

---------------------------------------------------------------

function editor.disconnect_iopole(procinfo, iopole_info)

    local index = iopole_info.index
    if index <= 0 then return end
    local point = procinfo.iopoints[index]

    point.disconnect_neighbour({
        wire = defines.wire_type.green,
        target_entity = iopole_info.entity
    })
    point.disconnect_neighbour({
        wire = defines.wire_type.red,
        target_entity = iopole_info.entity
    })
end

---------------------------------------------------------------

function editor.disconnect_all_iopoints(procinfo)

    for _, iopoint_info in pairs(procinfo.iopoint_infos) do
        editor.disconnect_iopole(procinfo, iopoint_info)
    end
end

---------------------------------------------------------------

local function create_iopoint(procinfo, entity, circuit)

    local iopoint_info = {

        entity = entity,
        index = circuit.index,
        label = circuit.label,
        red_display = circuit.red_display,
        green_display = circuit.green_display,
    }
    procinfo.iopoint_infos[entity.unit_number] = iopoint_info
    if not procinfo.is_packed then
        editor.connect_iopole(procinfo, iopoint_info)
    end
    return iopoint_info
end

---------------------------------------------------------------

function editor.update_io_text(iopoint_info)

    if iopoint_info.label == "" then
        if iopoint_info.text_id then
            rendering.destroy(iopoint_info.text_id)
            iopoint_info.text_id = nil
        end
    elseif iopoint_info.text_id then
        rendering.set_text(iopoint_info.text_id, iopoint_info.label)
        rendering.set_color(iopoint_info.text_id, iopoint_text_color)
    else
        iopoint_info.text_id = rendering.draw_text {
            text = iopoint_info.label,
            surface = iopoint_info.entity.surface,
            target = iopoint_info.entity,
            color = iopoint_text_color,
            only_in_alt_mode = true,
            alignment = "center",
            target_offset = { 0, -4 }
        }
    end
end

---------------------------------------------------------------

local display_options = {

    { "dropdown.all" },
    { "dropdown.one_line" },
    { "dropdown.none" }
}

local function on_gui_open_iopole(e)

    local player = game.players[e.player_index]
    local entity = e.entity
    if not entity or not entity.valid or entity.name ~= internal_iopoint_name then close_iopanel(player) return end

    player.opened = nil

    local vars = get_vars(player)
    local procinfo = global.surface_map[entity.surface.name]

    local ids = {}
    for i = 1, #procinfo.iopoints do
        table.insert(ids, tostring(i))
    end

    close_iopanel(player)

    vars.iopole = entity
    local iopoint_info = procinfo.iopoint_infos[entity.unit_number]

    local frame = player.gui.left.add { type = "frame", direction = "vertical", name = prefix .. "-iopole_panel" }

    local flow = frame.add { type = "flow", direction = "horizontal" }
    local label1 = flow.add { type = "label", caption = { "label.iopole_id" } }
    label1.style.width = 200
    local combo = flow.add { type = "drop-down", name = prefix .. ".iopole_index", items = ids,
        selected_index = iopoint_info.index }
    combo.style.width = 100

    flow = frame.add { type = "flow", direction = "horizontal" }
    local label2 = flow.add { type = "label", caption = { "label.iopole_name" } }
    label2.style.width = 200
    local name = flow.add { type = "textfield", name = prefix .. ".iopole_name", text = iopoint_info.label }

    flow = frame.add { type = "flow", direction = "horizontal" }
    flow.style.top_margin = 5
    flow.style.bottom_margin = 5
    flow.add { type = "label", caption = { "label.red_display" } }
    flow.add { type = "drop-down", name = prefix .. ".red_display", items = display_options,
        selected_index = iopoint_info.red_display and iopoint_info.red_display + 1 or 1 }

    local d = flow.add { type = "label", caption = { "label.green_display" } }
    d.style.left_margin = 10
    flow.add { type = "drop-down", name = prefix .. ".green_display", items = display_options,
        selected_index = iopoint_info.green_display and iopoint_info.green_display + 1 or 1 }

    frame.add { type = "button", caption = { "button.ok" }, name = prefix .. ".iopole_ok" }
end

---------------------------------------------------------------

function editor.get_iopoint_info(procinfo, iopole)
    local iopoint_infos = procinfo.iopoint_infos
    local iopoint_info = iopoint_infos[iopole.unit_number]
    if not iopoint_info then
        iopoint_info = {}
        iopoint_infos[iopole.unit_number] = iopoint_info
    end
    return iopoint_info
end

local get_iopoint_info = editor.get_iopoint_info

---------------------------------------------------------------

local iopole_fields = {
    [prefix .. ".iopole_index"] = true,
    [prefix .. ".red_display"] = true,
    [prefix .. ".green_display"] = true,

}

local function on_gui_selection_state_changed(e)
    if not e.element then return end

    local name = e.element.name
    if not iopole_fields[name] then return end

    local player = game.players[e.player_index]
    local vars = get_vars(player)
    local iopole = vars.iopole
    if not iopole or not iopole.valid then return end
    local procinfo = vars.procinfo
    local iopole_info = get_iopoint_info(procinfo, iopole)

    if name == prefix .. ".iopole_index" then
        if not procinfo.is_packed then
            editor.disconnect_iopole(procinfo, iopole_info)
        end
        iopole_info.index = e.element.selected_index
        if not procinfo.is_packed then
            editor.connect_iopole(procinfo, iopole_info)
        end
    elseif name == prefix .. ".red_display" then
        iopole_info.red_display = e.element.selected_index - 1
    elseif name == prefix .. ".green_display" then
        iopole_info.green_display = e.element.selected_index - 1
    end
end

---------------------------------------------------------------

local function on_gui_text_changed(e)
    if e.element and e.element.name == prefix .. ".iopole_name" then
        local player = game.players[e.player_index]
        local vars = get_vars(player)
        local iopole = vars.iopole
        if not iopole or not iopole.valid then return end
        local procinfo = vars.procinfo
        local iopoint_info = get_iopoint_info(procinfo, iopole)
        iopoint_info.label = e.element.text

        editor.update_io_text(iopoint_info)
    end
end

local function on_gui_confirmed(e)
    local player = game.players[e.player_index]
    close_iopanel(player)
end

---------------------------------------------------------------

function editor.set_circuits(procinfo, circuits, packed)

    procinfo.circuits = circuits
    if not procinfo.is_packed then

        if packed then
            editor.delete_surface(procinfo)
            editor.create_packed_circuit(procinfo)
            procinfo.is_packed = true
        else
            procinfo.surface = nil
            editor.get_or_create_surface(procinfo)
            editor.restore_packed_circuits(procinfo)
        end
    else
        editor.create_packed_circuit(procinfo)
    end
end

---------------------------------------------------------------

function editor.delete_surface(procinfo)

    if not procinfo.surface then return end

    global.surface_map[procinfo.surface.name] = nil
    game.delete_surface(procinfo.surface)
    procinfo.surface = nil
end

---------------------------------------------------------------

local function on_player_changed_surface(e)

    local player = game.players[e.player_index]
    local vars = get_vars(player)
    local procinfo = vars.procinfo

    local is_standard_exit = vars.is_standard_exit
    vars.is_standard_exit = false

    -- Exiting surface
    if procinfo and procinfo.surface and procinfo.surface.valid and procinfo.surface.index == e.surface_index then

        close_iopanel(player)
        close_editor_panel(player)

        player.opened = nil
        vars.procinfo = nil
        vars.processor = nil
        procinfo.circuits = editor.save_packed_circuits(procinfo)
        if (procinfo.is_packed) then

            if is_standard_exit then
                editor.delete_surface(procinfo)
                editor.create_packed_circuit(procinfo)
            else
                editor.destroy_packed_circuit(procinfo)
                editor.connect_all_iopoints(procinfo)
                procinfo.is_packed = false
            end
        end
    end

    local surface_name = player.surface.name
    procinfo = global.surface_map[surface_name]
    if procinfo then

        vars.procinfo = procinfo
        vars.processor = procinfo.processor
        editor.create_editor_panel(player, procinfo)
    end
end

---------------------------------------------------------------


tools.on_gui_click(prefix .. ".iopole_ok", function(e)
    local player = game.players[e.player_index]
    close_iopanel(player)
end)
tools.on_event(defines.events.on_gui_opened, on_gui_open_iopole)
tools.on_event(defines.events.on_gui_confirmed, on_gui_confirmed)
tools.on_event(defines.events.on_gui_selection_state_changed, on_gui_selection_state_changed)
tools.on_event(defines.events.on_gui_text_changed, on_gui_text_changed)
tools.on_event(defines.events.on_player_changed_surface, on_player_changed_surface)

--------------------------------------------------------------------------------------

local build_filter = tools.table_merge {
    {
        { filter = 'name', name = internal_iopoint_name }
    }
}

local function get_iopoint_map(procinfo)

    local map = {}
    for _, iopoint_info in pairs(procinfo.iopoint_infos) do
        if iopoint_info.index then
            map[iopoint_info.index] = iopoint_info
        end
    end
    return map
end

local function find_iopoint_index(procinfo)
    local map = get_iopoint_map(procinfo)
    for i = 1, #procinfo.iopoints do
        if not map[i] then
            return i
        end
    end
    return 0
end

local function check_ipoint_index(procinfo, index)
    local map = get_iopoint_map(procinfo)
    if index then
        if index > #procinfo.iopoints then 
            index = 1 
        end
        if not map[index] then return index end
    end
    for i = 1, #procinfo.iopoints do
        if not map[i] then
            return i
        end
    end
    return 0
end

local function init_internal_point(entity, tags, procinfo)
    local circuit = {
        label = ""
    }
    local label = ""
    local index
    if tags then
        circuit.label = tags.label
        circuit.index = check_ipoint_index(procinfo, tags.index)
        circuit.red_dispplay = tags.red_display
        circuit.green_display = tags.green_display
    else
        circuit.index = find_iopoint_index(procinfo)
    end
    local iopoint_info = create_iopoint(procinfo, entity, circuit)
    editor.update_io_text(iopoint_info)
end

local idp = "idp"

local textplate_map = {
    ["textplate-small-concrete"] = true,
    ["textplate-large-concrete"] = true,
    ["textplate-small-copper"] = true,
    ["textplate-large-copper"] = true,
    ["textplate-small-glass"] = true,
    ["textplate-large-glass"] = true,
    ["textplate-small-gold"] = true,
    ["textplate-large-gold"] = true,
    ["textplate-small-iron"] = true,
    ["textplate-large-iron"] = true,
    ["textplate-small-plastic"] = true,
    ["textplate-large-plastic"] = true,
    ["textplate-small-steel"] = true,
    ["textplate-large-steel"] = true,
    ["textplate-small-stone"] = true,
    ["textplate-large-stone"] = true,
    ["textplate-small-uranium"] = true,
    ["textplate-large-uranium"] = true,

    ["copper-display-small"] = idp,
    ["copper-display-medium"] = idp,
    ["copper-display"] = idp,
    ["iron-display-small"] = idp,
    ["iron-display-medium"] = idp,
    ["iron-display"] = idp,
    ["steel-display-small"] = idp,
    ["steel-display-medium"] = idp,
    ["steel-display"] = idp,
}

local remote_name_map = {}

local function is_allowed(name)
    local packed_name = allowed_name_map[name]
    if packed_name then return packed_name end

    if textplate_map[name] then return name end
    if remote_name_map[name] then return name end
    return nil
end

local function on_build(entity, e)

    if not entity or not entity.valid then return end

    local name = entity.name
    local procinfo = global.surface_map and global.surface_map[entity.surface.name]

    if name == internal_iopoint_name then
        if not procinfo then entity.destroy() return end
        init_internal_point(entity, e.tags, procinfo)
    elseif name == "entity-ghost" and is_allowed(entity.ghost_name) then
        if entity.ghost_name == internal_iopoint_name then
            if not procinfo then entity.destroy() return end
            local d, new = entity.silent_revive { raise_revive = true }
        else
            if not procinfo then return end
            if e.player_index then
                local player = game.players[e.player_index]
                local controller_type = player.controller_type
                if controller_type == defines.controllers.god then
                    entity.revive { raise_revive = true }
                end
            end
        end
    elseif procinfo and not is_allowed(name) then
        if not global.destroy_list then
            global.destroy_list = { entity }
        else
            table.insert(global.destroy_list, entity)
        end
    end
end

local function destroy_invalid(entity)

    entity.surface.create_entity { name = "flying-text", position = entity.position,
        text = { "message.not_allowed" } }
    local m = entity.prototype.mineable_properties
    local position = entity.position
    local surface = entity.surface
    local force = entity.force
    if not entity.mine { raise_destroyed = true, ignore_minable = true } then
        entity.destroy()
    end
    if m.minable and m.products then
        for _, p in pairs(m.products) do
            surface.spill_item_stack(position, { name = p.name, count = p.count }, true, force)
        end
    end
end

script.on_nth_tick(5, function(e)
    if not global.destroy_list then
        return
    end
    for _, entity in ipairs(global.destroy_list) do
        if entity.valid then
            destroy_invalid(entity)
        end
    end
    global.destroy_list = nil
end
)

local function on_robot_built(ev)
    local entity = ev.created_entity

    on_build(entity, ev)
end

local function on_script_built(ev)
    local entity = ev.entity

    on_build(entity, ev)
end

local function on_script_revive(ev)
    local entity = ev.entity

    on_build(entity, ev)
end

local function on_player_built(ev)
    local entity = ev.created_entity

    on_build(entity, ev)
end

local function on_marked_for_deconstruction(e)

    local player_index = e.player_index
    if not player_index then return end

    local player = game.players[e.player_index]
    local entity = e.entity
    local procinfo = global.surface_map and global.surface_map[entity.surface.name]
    if not procinfo then return end

    local controller_type = player.controller_type
    if controller_type == defines.controllers.god then

        if entity.name == internal_iopoint_name then
            editor.destroy_internal_iopoint(entity)
        end
        entity.destroy()
    end
end

tools.on_event(defines.events.on_built_entity, on_player_built)
tools.on_event(defines.events.on_robot_built_entity, on_robot_built)
tools.on_event(defines.events.script_raised_built, on_script_built)
tools.on_event(defines.events.script_raised_revive, on_script_revive)
tools.on_event(defines.events.on_marked_for_deconstruction, on_marked_for_deconstruction)

--------------------------------------------------------------------------------------

local filter_names = {
    {}
}

local surface_name_filter = {
    "constant-combinator",
    "decider-combinator",
    "arithmetic-combinator",
    "big-electric-pole",
    "small-electric-pole",
    "medium-electric-pole",
    "substation",
    internal_iopoint_name,
    "small-lamp"
}


for name, _ in pairs(textplate_map) do
    table.insert(surface_name_filter, name)
end

---------------------------------------------------------------

function editor.save_packed_circuits(procinfo)

    local surface = procinfo.surface
    if not surface or not surface.valid then return end

    local entities = surface.find_entities_filtered { name = surface_name_filter }
    local circuits = {}

    local unit_number_map = {}
    local sprite_map = nil

    local area
    for index, entity in ipairs(entities) do

        if entity.unit_number then

            local position = entity.position
            local entity_info = {
                name = entity.name,
                index = index,
                position = position,
                direction = entity.direction
            }
            table.insert(circuits, entity_info)
            unit_number_map[entity.unit_number] = index
            local name = entity.name

            local graphics_variation = entity.graphics_variation
            if graphics_variation then
                entity_info.graphics_variation = graphics_variation
            end

            if remote_name_map[name] then
                local remote_driver = remote_name_map[name]
                local remoteInfo = remote.call(remote_driver.interface_name, "get_info", entity)
                for name, value in pairs(remoteInfo) do
                    entity_info[name] = value
                end
            elseif entity.type == "constant-combinator" then
                local cb = entity.get_control_behavior()
                if cb then
                    local parameters = {}
                    for i, p in ipairs(cb.parameters) do
                        if p and p.signal.name then
                            table.insert(parameters, p)
                        end
                    end
                    entity_info.parameters = parameters
                    entity_info.enabled = cb.enabled
                end
            elseif entity.type == "decider-combinator" then
                local cb = entity.get_control_behavior()
                if cb then
                    entity_info.parameters = cb.parameters
                end
            elseif entity.type == "arithmetic-combinator" then
                local cb = entity.get_control_behavior()
                if cb then
                    entity_info.parameters = cb.parameters
                end
            elseif name == "small-lamp" then
                local cb = entity.get_control_behavior()
                if cb then
                    entity_info.circuit_condition = cb.circuit_condition
                    entity_info.use_colors        = cb.use_colors
                end
                if not area then
                    area = { min = { x = position.x, y = position.y }, max = { x = position.x, y = position.y } }
                else
                    if position.x < area.min.x then area.min.x = position.x end
                    if position.y < area.min.y then area.min.y = position.y end
                    if position.x > area.max.x then area.max.x = position.x end
                    if position.y > area.max.y then area.max.y = position.y end
                end
            elseif entity.name == internal_iopoint_name then
                local iopoint_info = procinfo.iopoint_infos[entity.unit_number]
                entity_info.index = iopoint_info.index
                entity_info.label = iopoint_info.label
                entity_info.red_display = iopoint_info.red_display
                entity_info.green_display = iopoint_info.green_display
            elseif textplate_map[name] == idp then
                sprite_map                     = editor.get_reverse_sprite_map(sprite_map)
                local sprite_type, sprite_name = editor.get_render_sprite_info(sprite_map, entity)
                if sprite_type then
                    entity_info.sprite_type = sprite_type
                    entity_info.sprite_name = sprite_name
                end
            end
        end
    end

    for index, entity in ipairs(entities) do
        local connections = entity.circuit_connection_definitions
        if connections then
            local mapped_connections = {}
            circuits[index].connections = mapped_connections
            for _, connection in ipairs(connections) do
                local target = connection.target_entity
                local target_index = unit_number_map[target.unit_number]
                if target_index then
                    if target_index < index or
                        (target_index == index and connection.source_circuit_id < connection.target_circuit_id) then
                        table.insert(mapped_connections,
                            {
                                wire = connection.wire,
                                target_entity = target_index,
                                source_circuit_id = connection.source_circuit_id,
                                target_circuit_id = connection.target_circuit_id
                            })
                    end
                end
            end
        end

    end
    if area then
        local size = math.max(area.max.x - area.min.x, area.max.y - area.min.y)
        local width = 1.5
        local lamp_name
        local size1 = size + 1

        local selection_box = procinfo.processor.selection_box 
        local selection_width = selection_box.right_bottom.x - selection_box.left_top.x
        local scale = selection_width / 2.4

        if size < 1 then size = 1 end

        local resize_coef = 0.58
        local lamp_index = math.ceil(math.log(math.ceil(size1 / width * resize_coef / scale), 2)) + 1
        if lamp_index < 1 then
            lamp_index = 1
        elseif lamp_index >= 8 then
            lamp_index = 8
        end

        local center = { x = (area.max.x + area.min.x) / 2, y = (area.min.y + area.max.y) / 2 }

        local lamp_size = math.pow(0.5, lamp_index - 1) * resize_coef 
        local coef = lamp_size

        --debug("area=" .. strip(area) .. ",center=" .. strip(center)  .. ",size=" .. size .. ",lamp_size="  .. lamp_size)
        --debug("lamp_index=" .. lamp_index .. ",coef=" .. coef .. ",width=" .. width)

        lamp_name = prefix .. "-lamp" .. lamp_index

        for _, circuit in pairs(circuits) do
            if circuit.name == "small-lamp" then
                local x = (circuit.position.x - center.x) * coef
                local y = (circuit.position.y - center.y) * coef
                circuit.ext_position = { x = x, y = y }
                circuit.ext_name = lamp_name
            end
        end
    end

    procinfo.circuits = circuits
    return circuits
end

---------------------------------------------------------------

local function check_signal(type, name)
    if type == "virtual" then
        return game.virtual_signal_prototypes[name]
    elseif type == "item" then
        return game.item_prototypes[name]
    elseif type == "fluid" then
        return game.fluid_prototypes[name]
    end
    return true
end

local function check_signal_o(signal)
    if not signal then return true end
    return check_signal(signal.type, signal.name)
end

local function check_parameters(type, parameters)

    if type == "constant-combinator" then
        for _, r in pairs(parameters) do
            if not check_signal_o(r.signal) then
                return nil
            end
        end
    elseif type == "arithmetic-combinator" or type == "decider-combinator" then
        if not check_signal_o(parameters.first_signal) then return nil end
        if not check_signal_o(parameters.second_signal) then return nil end
        if not check_signal_o(parameters.output_signal) then return nil end
    end
    return parameters
end

---------------------------------------------------------------

function editor.restore_packed_circuits(procinfo)

    if not procinfo.circuits then return end

    local entities = {}
    local force = procinfo.processor.force
    procinfo.iopoint_infos = {}
    for _, circuit in ipairs(procinfo.circuits) do

        local name = circuit.name
        if not game.entity_prototypes[name] then
            table.insert(entities, {})
        elseif circuit.sprite_type then
            local entity = procinfo.surface.create_entity {
                name = "entity-ghost",
                inner_name = name,
                position = circuit.position,
                direction = circuit.direction,
                force = force,
                create_build_effect_smoke = false
            }
            entity.tags = {
                ["display-plate-sprite-type"] = circuit.sprite_type,
                ["display-plate-sprite-name"] = circuit.sprite_name
            }
            entity = entity.revive { raise_revive = true }
            table.insert(entities, entity)
        else

            local entity
            local remote_driver = remote_name_map[name]
            if remote_driver then
                entity = remote.call(remote_driver.interface_name, "create_entity", circuit, procinfo.surface,
                    force)
                table.insert(entities, entity)
            else

                entity = procinfo.surface.create_entity {
                    name = name,
                    position = circuit.position,
                    direction = circuit.direction,
                    force = force,
                    create_build_effect_smoke = false
                }
                if circuit.graphics_variation then
                    entity.graphics_variation = circuit.graphics_variation
                end
                table.insert(entities, entity)

                if circuit.parameters then
                    local cb = entity.get_or_create_control_behavior()
                    local parameters = check_parameters(entity.type, circuit.parameters)
                    if parameters then
                        cb.parameters = parameters
                    end
                    if entity.type == "constant-combinator" then
                        cb.enabled = circuit.enabled == nil and true or circuit.enabled
                    end
                elseif name == internal_iopoint_name then
                    local iopoint_info = create_iopoint(procinfo, entity, circuit)
                    editor.update_io_text(iopoint_info)
                elseif name == "small-lamp" then
                    if circuit.circuit_condition then
                        local cb = entity.get_or_create_control_behavior()
                        cb.circuit_condition = circuit.circuit_condition
                        cb.use_colors = circuit.use_colors
                    end
                end
            end

            if circuit.connections then
                for _, connection in ipairs(circuit.connections) do
                    local target = entities[connection.target_entity]
                    if target and target.name then
                        local success = entity.connect_neighbour {
                            wire = connection.wire,
                            target_entity = target,
                            source_circuit_id = connection.source_circuit_id,
                            target_circuit_id = connection.target_circuit_id
                        }
                        if not success then
                            debug("Fail connect restore:(" ..
                                entity.name ..
                                ":" .. entity.unit_number .. "=>" .. target.name .. ":" .. target.unit_number .. ")")
                        end
                    end
                end
            end
        end
    end
end

---------------------------------------------------------------

function editor.create_packed_circuit(procinfo)

    editor.destroy_packed_circuit(procinfo)
    if not procinfo.circuits then return end


    local entities = {}
    local processor = procinfo.processor
    local position = processor.position
    local surface = processor.surface
    local force = processor.force
    if not surface.valid then return end

    local selection_box = procinfo.processor.selection_box 
    local selection_width = selection_box.right_bottom.x - selection_box.left_top.x
    local scale = selection_width / 2.4

    for index, circuit in ipairs(procinfo.circuits) do

        local name = circuit.name
        local packed_name = allowed_name_map[name]

        local entity = nil
        if packed_name then
            local pos = position
            if circuit.ext_name then
                packed_name = circuit.ext_name
                pos = { x = position.x + circuit.ext_position.x, y = position.y + circuit.ext_position.y }
            else
                pos = {x = pos.x + circuit.position.x / 32 * scale, y = pos.y + circuit.position.y / 32 * scale }
            end

            entity = surface.create_entity { name = packed_name, position = pos,
                direction = circuit.direction, force = force }

            table.insert(entities, entity)

            if circuit.parameters then
                local cb = entity.get_or_create_control_behavior()
                local parameters = check_parameters(entity.type, circuit.parameters)
                if parameters then
                    cb.parameters = parameters
                    if entity.type == "constant-combinator" then
                        cb.enabled = circuit.enabled == nil and true or circuit.enabled
                    end
                end
            elseif name == internal_iopoint_name then

                local iopoint = procinfo.iopoints[circuit.index]
                iopoint.get_or_create_control_behavior()
                iopoint.active = false
                local success1 = iopoint.connect_neighbour({
                    wire = defines.wire_type.green,
                    target_entity = entity
                })
                local success2 = iopoint.connect_neighbour({
                    wire = defines.wire_type.red,
                    target_entity = entity
                })
                if not success1 or not success2 then
                    debug("Failed to connect iopoint: " ..
                        circuit.index .. "," .. strip(entity.position) .. " to " .. strip(iopoint.position))
                    debug("Failed to connect iopoint: " .. entity.name .. " to " .. iopoint.name)
                    debug("Failed to connect iopoint: " .. entity.unit_number .. " to " .. iopoint.unit_number)
                end
            elseif name == "small-lamp" then
                if circuit.circuit_condition then
                    local cb = entity.get_or_create_control_behavior()
                    cb.circuit_condition = circuit.circuit_condition
                    cb.use_colors = circuit.use_colors
                end
            end
        elseif textplate_map[name] then
            table.insert(entities, {})
        elseif remote_name_map[name] then
            local remote_driver = remote_name_map[name]
            local pos = {x = position.x + circuit.position.x / 32, y = position.y + circuit.position.y / 32 }
            entity = remote.call(remote_driver.interface_name, "create_packed_entity", circuit, surface, pos,
                force)
            if entity then
                table.insert(entities, entity)
            else
                table.insert(entities, {})
            end
        else
            table.insert(entities, {})
        end

        if entity and circuit.connections then
            for _, connection in ipairs(circuit.connections) do
                local targetc = entities[connection.target_entity]
                if targetc and targetc.name then
                    local success = entity.connect_neighbour {
                        wire = connection.wire,
                        target_entity = targetc,
                        source_circuit_id = connection.source_circuit_id,
                        target_circuit_id = connection.target_circuit_id
                    }
                    if not success then
                        debug("Failed to connect: " ..
                            connection.target_entity ..
                            "," .. strip(entity.position) .. " to " .. strip(targetc.position))
                        debug("Failed to connect: " .. entity.name .. " to " .. targetc.name)
                        debug("Failed to connect: " .. entity.unit_number .. " to " .. targetc.unit_number)
                    end
                end
            end
        end

    end
end

function editor.destroy_packed_circuit(procinfo)
    local processor = procinfo.processor

    tools.destroy_entities(processor, commons.packed_entities)
end

--------------------------------------------------------------------------------------

function editor.destroy_internal_iopoint(entity)
    if not entity.valid then return end

    local procinfo = global.surface_map[entity.surface.name]
    if not procinfo then return end

    procinfo.iopoint_infos[entity.unit_number] = nil
    tools.close_ui(entity.unit_number, close_iopanel, "iopole")
end

local function on_mined(ev)
    local entity = ev.entity
    if entity.name == internal_iopoint_name then

        editor.destroy_internal_iopoint(entity)
        if ev.buffer then
            ev.buffer.clear()
        end
    end
end

local function on_player_mined_entity(ev)
    on_mined(ev)
end

local mine_filter = {
    { filter = 'name', name = internal_iopoint_name }
}
tools.on_event(defines.events.on_player_mined_entity, on_player_mined_entity, mine_filter)
tools.on_event(defines.events.on_robot_mined_entity, on_mined, mine_filter)
tools.on_event(defines.events.on_entity_died, on_mined, mine_filter)
tools.on_event(defines.events.script_raised_destroy, on_mined, mine_filter)

function editor.get_reverse_sprite_map(map)

    if map then return map end

    map = {}
    local ids = rendering.get_all_ids()
    for _, id in pairs(ids) do
        local target = rendering.get_target(id)
        if target then
            local entity = target.entity
            if entity and entity.valid and entity.unit_number then
                map[entity.unit_number] = id
            end
        end
    end
    return map
end

local function split_string(s)
    local result = {};
    for m in (s .. "/"):gmatch("(.-)/") do
        table.insert(result, m);
    end
    return result
end

function editor.get_render_sprite_info(map, entity)
    local id = map[entity.unit_number]
    if id then
        local sprite = rendering.get_sprite(id)
        local strings = split_string(sprite)
        return strings[1], strings[2]
    end
    return nil, nil
end

local forbidden_prototypes = {

    "container",
    "logistic-container",
    "assembling-machine",
    "boiler",
    "transport-belt",
    "underground-belt",
    "splitter",
    "loader",
    "loader-1x1",
    "pipe",
    "pipe-to-ground",
    "rail"
}

function editor.add_combinator(driver)

    if remote_name_map[driver.name] then return end

    local proto = game.entity_prototypes[driver.name]
    if forbidden_prototypes[proto.type] then return end

    remote_name_map[driver.name] = driver
    table.insert(surface_name_filter, driver.name)
    local packed_names = driver.packed_names
    if packed_names then
        for _, name in ipairs(packed_names) do
            table.insert(commons.packed_entities, name)
            table.insert(commons.entities_to_destroy, name)
        end
    end
end

function editor.remove_combinator(name)

    local driver = remote_name_map[name]
    if not driver then return end

    remote_name_map[name] = driver
    for i, n in ipairs(surface_name_filter) do
        if n == name then
            table.remove(surface_name_filter, i)
            break
        end
    end

    local packed_names = driver.packed_names
    if packed_names then
        for _, np in ipairs(packed_names) do
            for i, n in ipairs(commons.packed_entities) do
                if n == np then
                    table.remove(commons.packed_entities, i)
                    break
                end
            end
            for i, n in ipairs(commons.entities_to_destroy) do
                if n == np then
                    table.remove(commons.entities_to_destroy, i)
                    break
                end
            end
        end
    end
end

remote.add_interface(prefix,
    { add_combinator = editor.add_combinator,
        remove_combinator = editor.remove_combinator
    }
)

--[[
    Remote fields:

        name: string, entity name

        packed_names: string[] , liste of entities used in packed mode

        interface_name : name of reverse interface

    Reverse interface:

        get_info(entity) : add private information on entities
            return {a structure containing private information}
            reserved fields:
                name,  index, position, direction

        create_packed_entity(info, surface, position, force)
            create a packed entity from 'info' structure'

        create_entity(info, surface, force)
            create a normal entity from information
            (position, direction, name) is in 'info' structure
        
--]]

return editor

-------------------------------------

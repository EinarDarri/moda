local commons = require("scripts.commons")

local debug_mode = commons.debug_mode
local combinators = {}

local function png(name) return ('__compaktcircuit__/graphics/%s.png'):format(name) end

combinators.png = png

local no_energy = false
local boxsize = commons.boxsize

function combinators.merge_table(dst, sources)
	for _, src in pairs(sources) do
		for name, value in pairs(src) do
			dst[name] = value
		end
	end
	return dst
end

local function table_add(t, e)
	for _, s in ipairs(t) do
		if s == e then return end
	end
	table.insert(t, e)
end

local merge_table = combinators.merge_table

local function scale_vect(v, scale)
	return { v[1] * scale, v[2] * scale }
end

local function scale_connector(c, scale)
	if c.scale then
		c.scale = scale * c.scale
	end
	if c.shift then
		c.shift = scale_vect(c.shift, scale)
	end
	if c.filename then
		c.filename = png("invisible")
		c.width = 1
		c.height = 1
		c.x = 0
		c.y = 0
	end
end

local function scale_picture(p, scale)

	if p.scale then
		p.scale = scale * p.scale
	else
		p.scale = scale
	end
	if p.shift then
		p.shift = scale_vect(p.shift, scale)
	end
end

local function scale_lamp(name, scale)

	local lamp = table.deepcopy(data.raw["lamp"]["small-lamp"])
	local connectors = lamp.circuit_connector_sprites

	connectors.blue_led_light_offset = scale_vect(connectors.blue_led_light_offset, scale)
	connectors.red_green_led_light_offset = scale_vect(connectors.red_green_led_light_offset, scale)
	connectors.led_light.size = scale * connectors.led_light.size

	scale_connector(connectors.connector_main, scale)
	scale_connector(connectors.connector_shadow, scale)
	scale_connector(connectors.led_blue, scale)
	scale_connector(connectors.led_blue_off, scale)
	scale_connector(connectors.led_green, scale)
	scale_connector(connectors.led_red, scale)
	scale_connector(connectors.wire_pins, scale)
	scale_connector(connectors.wire_pins_shadow, scale)

	local points = lamp.circuit_wire_connection_point
	points.shadow.green = scale_vect(points.shadow.green, scale)
	points.shadow.red = scale_vect(points.shadow.red, scale)
	points.wire.green = scale_vect(points.wire.green, scale)
	points.wire.red = scale_vect(points.wire.red, scale)

	scale_picture(lamp.picture_off.layers[1], scale)
	scale_picture(lamp.picture_off.layers[1].hr_version, scale)
	scale_picture(lamp.picture_off.layers[2], scale)
	scale_picture(lamp.picture_off.layers[2].hr_version, scale)
	scale_picture(lamp.picture_on, scale)
	scale_picture(lamp.picture_on.hr_version, scale)

	lamp.flags = { "hide-alt-info", "not-on-map", "not-upgradable", "not-deconstructable", "not-blueprintable",
		"placeable-off-grid", "hidden" }
	lamp.name = name
	lamp.collision_box = { { -boxsize, -boxsize }, { boxsize, boxsize } }
	lamp.collision_mask = {}
	lamp.selection_box = { { -0.01, -0.01 }, { 0.01, 0.01 } }
	lamp.selectable_in_game = false
	lamp.draw_circuit_wires = false
	lamp.draw_copper_wires = false
	lamp.energy_usage_per_tick = "10W"
	lamp.light.size = 4
	lamp.light_when_colored.size = 4
	--lamp.always_on = true
	lamp.picture_off.layers[1].filename = png("entity/lamp/lamp")
	lamp.picture_off.layers[1].hr_version.filename = png("entity/lamp/hr-lamp")
	lamp.energy_source = { type = "void" }

	return lamp
end

function combinators.create_internals()

	local invisible_sprite = { filename = png('invisible'), width = 1, height = 1 }
	local wire_conn = { wire = { red = { 0, 0 }, green = { 0, 0 } }, shadow = { red = { 0, 0 }, green = { 0, 0 } } }
	local commons_attr = {
		flags = { 'placeable-off-grid' },
		collision_mask = {},
		minable = nil,
		selectable_in_game = debug_mode,
		circuit_wire_max_distance = 64,
		sprites = invisible_sprite,
		activity_led_sprites = invisible_sprite,
		activity_led_light_offsets = { { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } },
		circuit_wire_connection_points = { wire_conn, wire_conn, wire_conn, wire_conn },
		draw_circuit_wires = debug_mode,
		collision_box = { { -boxsize, -boxsize }, { boxsize, boxsize } },
		created_smoke = nil,
		selection_box = { { -0.01, -0.01 }, { 0.01, 0.01 } },
		maximum_wire_distance = 2

	}

	local energy_attr

	if no_energy then
		energy_attr = { 
			active_energy_usage = "0.01KW",
			energy_source = { type = "void" } 
		}
	else
		energy_attr = {
			active_energy_usage = "1KW",
			energy_source = {
				type = "electric",
				usage_priority = "secondary-input",
				render_no_power_icon = false,
				render_no_network_icon = false
			}
		}
	end

	if (debug_mode) then
		commons_attr.selection_priority = 60
	end

	local function insert_flags(flags)

		if not debug_mode then
			table_add(flags, "hidden")
			table_add(flags, "hide-alt-info")
			table_add(flags, "not-on-map")
		end
		--table.insert(flags, "placeable-neutral")
		--table.insert(flags, "placeable-player")
		--table.insert(flags, "player-creation")
		table_add(flags, "not-upgradable")
		table_add(flags, "not-deconstructable")
		table_add(flags, "not-blueprintable")
	end

	--------------------------------------------------------

	local constant_combinator = table.deepcopy(data.raw["constant-combinator"]["constant-combinator"])
	constant_combinator = merge_table(constant_combinator, { commons_attr, {
		name = commons.prefix .. '-cc',
		item_slot_count = 100
	} })
	insert_flags(constant_combinator.flags)

	--------------------------------------------------------

	local cc2 = table.deepcopy(constant_combinator)
	cc2.name = commons.prefix .. "-cc2"

	--------------------------------------------------------

	local arithmetic_combinator = table.deepcopy(data.raw["arithmetic-combinator"]["arithmetic-combinator"])
	arithmetic_combinator       = merge_table(arithmetic_combinator, {

		commons_attr, {
			name = commons.prefix .. '-ac',
			and_symbol_sprites = invisible_sprite,
			divide_symbol_sprites = invisible_sprite,
			left_shift_symbol_sprites = invisible_sprite,
			minus_symbol_sprites = invisible_sprite,
			plus_symbol_sprites = invisible_sprite,
			power_symbol_sprites = invisible_sprite,
			multiply_symbol_sprites = invisible_sprite,
			or_symbol_sprites = invisible_sprite,
			right_shift_symbol_sprites = invisible_sprite,
			xor_symbol_sprites = invisible_sprite,
			modulo_symbol_sprites = invisible_sprite
		}, energy_attr
	})
	insert_flags(arithmetic_combinator.flags)

	--------------------------------------------------------

	local decider_combinator = table.deepcopy(data.raw["decider-combinator"]["decider-combinator"])
	decider_combinator       = merge_table(decider_combinator, { commons_attr, {
		name = commons.prefix .. '-dc',
		equal_symbol_sprites = invisible_sprite,
		greater_or_equal_symbol_sprites = invisible_sprite,
		greater_symbol_sprites = invisible_sprite,
		less_or_equal_symbol_sprites = invisible_sprite,
		less_symbol_sprites = invisible_sprite,
		not_equal_symbol_sprites = invisible_sprite
	}, energy_attr })
	insert_flags(decider_combinator.flags)

	--------------------------------------------------------

	local pole = {

		type = "electric-pole",
		name = commons.prefix .. "-pole",
		minable = nil,
		collision_box = { { -boxsize, -boxsize }, { boxsize, boxsize } },
		collision_mask = {},
		selection_box = { { -0.01, -0.01 }, { 0.01, 0.01 } },
		draw_copper_wires = debug_mode,
		draw_circuit_wires = debug_mode,
		connection_points = {
			{ wire = { red = { 0, 0 }, green = { 0, 0 } }, shadow = { red = { 0, 0 }, green = { 0, 0 } } }
		},
		selectable_in_game = debug_mode,
		pictures = {
			count = 1,
			filename = png("invisible"),
			width = 1,
			height = 1,
			direction_count = 1
		},
		maximum_wire_distance = 3,
		supply_area_distance = 0.5,
		max_health = 10,
		flags = {
			"placeable-off-grid"
		}
	}
	insert_flags(pole.flags)

	--------------------------------------------------------

	local epole = table.deepcopy(pole)
	epole.name = commons.prefix .. "-epole"
	epole.connection_points = {
		{ wire = { copper = { 0, 0 } }, shadow = { copper = { 0, 0 } } }
	}
	epole.draw_copper_wires = true

	--------------------------------------------------------

	local accu = {

		type = "accumulator",
		name = commons.prefix .. "-accu",
		charge_cooldown = 30,
		discharge_cooldown = 60,
		selectable_in_game = debug_mode,
		energy_source = {
			buffer_capacity = "100KJ",
			input_flow_limit = "20MW",
			output_flow_limit = "20MW",
			type = "electric",
			usage_priority = "tertiary",
			render_no_power_icon = false,
			render_no_network_icon = false
		},
		picture = {
			filename = png("invisible"),
			width = 1,
			height = 1,
			direction_count = 1
		},
		flags = {}
	}
	insert_flags(accu.flags)

	--------------------------------------------------------


	data:extend {
		constant_combinator,
		cc2,
		arithmetic_combinator,
		decider_combinator,
		pole,
		epole,
		accu
	}

	local lamp_table = {}
	local scale = 1.0
	for i = 1, 8 do
		local lamp = scale_lamp(commons.prefix .. "-lamp" .. i, scale)
		table.insert(lamp_table, lamp)
		scale = scale / 2.0
	end
	data:extend(lamp_table)
end

-- log(serpent.block(data.raw["lamp"]["small-lamp"]))

return combinators
